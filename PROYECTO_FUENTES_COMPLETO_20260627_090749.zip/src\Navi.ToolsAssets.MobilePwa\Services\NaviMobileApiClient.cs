﻿using System.Net.Http.Json;
using System.Text.Json;
using Navi.ToolsAssets.MobilePwa.Models;

namespace Navi.ToolsAssets.MobilePwa.Services;

public sealed class NaviMobileApiClient
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = true
    };

    private readonly HttpClient _http;
    private readonly MobileAuthSessionService _auth;

    private List<MobileToolDto>? _toolsCache;
    private DateTimeOffset? _toolsCacheAt;
    private MobileExecutiveDashboard? _dashboardCache;
    private DateTimeOffset? _dashboardCacheAt;

    private readonly TimeSpan _cacheDuration = TimeSpan.FromMinutes(3);

    public NaviMobileApiClient(HttpClient http, MobileAuthSessionService auth)
    {
        _http = http;
        _auth = auth;
    }

    public async Task<MobileUser> LoginAsync(string userName, string password)
    {
        var response = await _http.PostAsJsonAsync("api/auth/login", new MobileLoginRequest
        {
            UserName = userName,
            Password = password
        });

        using (response)
        {
            if (!response.IsSuccessStatusCode)
            {
                throw new InvalidOperationException(await ReadApiErrorAsync(response));
            }

            var user = await response.Content.ReadFromJsonAsync<MobileUser>(JsonOptions);

            if (user is null)
            {
                throw new InvalidOperationException("No se recibió información de sesión.");
            }

            ClearCache();

            await _auth.LoginAsync(user);

            return user;
        }
    }

    public async Task<MobileExecutiveDashboard> GetDashboardAsync(bool forceRefresh = false)
    {
        if (!forceRefresh &&
            _dashboardCache is not null &&
            _dashboardCacheAt.HasValue &&
            DateTimeOffset.Now - _dashboardCacheAt.Value < _cacheDuration)
        {
            return _dashboardCache;
        }

        using var request = new HttpRequestMessage(HttpMethod.Get, "api/dashboard/executive");

        ApplySecurityHeaders(request);

        using var response = await _http.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            throw new InvalidOperationException(await ReadApiErrorAsync(response));
        }

        var dashboard = await response.Content.ReadFromJsonAsync<MobileExecutiveDashboard>(JsonOptions);

        if (dashboard is null)
        {
            throw new InvalidOperationException("No se recibió información del dashboard.");
        }

        _dashboardCache = dashboard;
        _dashboardCacheAt = DateTimeOffset.Now;

        return dashboard;
    }

    public async Task<List<MobileToolDto>> GetToolsAsync(bool forceRefresh = false)
    {
        if (!forceRefresh &&
            _toolsCache is not null &&
            _toolsCacheAt.HasValue &&
            DateTimeOffset.Now - _toolsCacheAt.Value < _cacheDuration)
        {
            return _toolsCache;
        }

        using var request = new HttpRequestMessage(HttpMethod.Get, "api/tools");

        ApplySecurityHeaders(request);

        using var response = await _http.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            throw new InvalidOperationException(await ReadApiErrorAsync(response));
        }

        var tools = await response.Content.ReadFromJsonAsync<List<MobileToolDto>>(JsonOptions) ?? new();

        _toolsCache = tools;
        _toolsCacheAt = DateTimeOffset.Now;

        return tools;
    }

    public async Task<MobileToolDto> GetToolByIdAsync(Guid id)
    {
        var tools = await GetToolsAsync();

        var tool = tools.FirstOrDefault(x => x.Id == id);

        if (tool is not null)
        {
            return tool;
        }

        tools = await GetToolsAsync(forceRefresh: true);

        tool = tools.FirstOrDefault(x => x.Id == id);

        if (tool is null)
        {
            throw new InvalidOperationException("No se encontró el activo solicitado en el inventario visible.");
        }

        return tool;
    }

    public async Task<MobileToolDetailDto> GetToolDetailAsync(Guid id)
    {
        using var request = new HttpRequestMessage(HttpMethod.Get, $"api/tools/{id}");

        ApplySecurityHeaders(request);

        using var response = await _http.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            throw new InvalidOperationException(await ReadApiErrorAsync(response));
        }

        var tool = await response.Content.ReadFromJsonAsync<MobileToolDetailDto>(JsonOptions);

        if (tool is null)
        {
            throw new InvalidOperationException("No se recibió el detalle del activo.");
        }

        return tool;
    }

    public async Task<List<MobileLifeCycleEventDto>> GetLifeCycleEventsAsync(Guid id)
    {
        using var request = new HttpRequestMessage(HttpMethod.Get, $"api/tools/{id}/life-cycle-events");

        ApplySecurityHeaders(request);

        using var response = await _http.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            throw new InvalidOperationException(await ReadApiErrorAsync(response));
        }

        return await response.Content.ReadFromJsonAsync<List<MobileLifeCycleEventDto>>(JsonOptions) ?? new();
    }

    public async Task<MobileTechnicalLifeRecordDto> GetTechnicalLifeRecordAsync(Guid id)
    {
        using var request = new HttpRequestMessage(HttpMethod.Get, $"api/tools/{id}/technical-life-record");

        ApplySecurityHeaders(request);

        using var response = await _http.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            throw new InvalidOperationException(await ReadApiErrorAsync(response));
        }

        var lifeRecord = await response.Content.ReadFromJsonAsync<MobileTechnicalLifeRecordDto>(JsonOptions);

        if (lifeRecord is null)
        {
            throw new InvalidOperationException("No se recibió la hoja de vida técnica.");
        }

        return lifeRecord;
    }

    public async Task<MobileDamageReportResponse> ReportDamageAsync(MobileDamageReportRequest body)
    {
        using var request = new HttpRequestMessage(HttpMethod.Post, "api/damages/report");

        ApplySecurityHeaders(request);

        request.Content = JsonContent.Create(body);

        using var response = await _http.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            throw new InvalidOperationException(await ReadApiErrorAsync(response));
        }

        var result = await response.Content.ReadFromJsonAsync<MobileDamageReportResponse>(JsonOptions);

        if (result is null)
        {
            throw new InvalidOperationException("No se recibió respuesta del reporte.");
        }

        ClearCache();

        return result;
    }


    public async Task<List<MobileAvailabilityToolDto>> GetAvailabilityToolsAsync()
    {
        using var request = new HttpRequestMessage(HttpMethod.Get, "api/tools");

        ApplySecurityHeaders(request);

        using var response = await _http.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            throw new InvalidOperationException(await ReadMobileAvailabilityApiErrorAsync(response));
        }

        return await response.Content.ReadFromJsonAsync<List<MobileAvailabilityToolDto>>(JsonOptions) ?? new();
    }

    public async Task<List<MobileBranchDto>> GetBranchesAsync()
    {
        using var request = new HttpRequestMessage(HttpMethod.Get, "api/settings/branches");

        ApplySecurityHeaders(request);

        using var response = await _http.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            throw new InvalidOperationException(await ReadMobileAvailabilityApiErrorAsync(response));
        }

        return await response.Content.ReadFromJsonAsync<List<MobileBranchDto>>(JsonOptions) ?? new();
    }

    public async Task<List<MobileLocationDto>> GetLocationsAsync()
    {
        try
        {
            using var request = new HttpRequestMessage(HttpMethod.Get, "api/settings/locations");

            ApplySecurityHeaders(request);

            using var response = await _http.SendAsync(request);

            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadFromJsonAsync<List<MobileLocationDto>>(JsonOptions) ?? new();
            }
        }
        catch
        {
        }

        using var fallbackRequest = new HttpRequestMessage(HttpMethod.Get, "api/settings/warehouses");

        ApplySecurityHeaders(fallbackRequest);

        using var fallbackResponse = await _http.SendAsync(fallbackRequest);

        if (!fallbackResponse.IsSuccessStatusCode)
        {
            throw new InvalidOperationException(await ReadMobileAvailabilityApiErrorAsync(fallbackResponse));
        }

        return await fallbackResponse.Content.ReadFromJsonAsync<List<MobileLocationDto>>(JsonOptions) ?? new();
    }

    public async Task UpdateAvailabilityLocationAsync(MobileAvailabilityLocationRequest body)
    {
        if (body.ToolId == Guid.Empty)
        {
            throw new InvalidOperationException("Debe seleccionar una herramienta o activo.");
        }

        if (body.BranchId == Guid.Empty)
        {
            throw new InvalidOperationException("Debe seleccionar una sede.");
        }

        using var request = new HttpRequestMessage(HttpMethod.Patch, $"api/tools/{body.ToolId}/availability-location");

        ApplySecurityHeaders(request);

        request.Content = JsonContent.Create(new
        {
            branchId = body.BranchId,
            locationId = body.LocationId,
            operationalStatus = body.OperationalStatus,
            observation = body.Observation,
            changedBy = body.ChangedBy
        });

        using var response = await _http.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            throw new InvalidOperationException(await ReadMobileAvailabilityApiErrorAsync(response));
        }

        ClearCache();
    }

    private static async Task<string> ReadMobileAvailabilityApiErrorAsync(HttpResponseMessage response)
    {
        var content = await response.Content.ReadAsStringAsync();

        if (string.IsNullOrWhiteSpace(content))
        {
            return $"Error HTTP {(int)response.StatusCode}: {response.ReasonPhrase}";
        }

        return content;
    }

    public async Task<List<MobileLoanRequestDto>> GetLoanRequestsAsync()
    {
        using var request = new HttpRequestMessage(HttpMethod.Get, "api/loans");

        ApplySecurityHeaders(request);

        using var response = await _http.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            throw new InvalidOperationException(await ReadApiErrorAsync(response));
        }

        return await response.Content.ReadFromJsonAsync<List<MobileLoanRequestDto>>(JsonOptions) ?? new();
    }

    public async Task<List<MobileResponsibleDto>> GetResponsiblesAsync()
    {
        using var request = new HttpRequestMessage(HttpMethod.Get, "api/settings/responsibles");

        ApplySecurityHeaders(request);

        using var response = await _http.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            throw new InvalidOperationException(await ReadApiErrorAsync(response));
        }

        return await response.Content.ReadFromJsonAsync<List<MobileResponsibleDto>>(JsonOptions) ?? new();
    }

    public async Task CreateLoanRequestAsync(MobileLoanRequestCreateDto body)
    {
        using var request = new HttpRequestMessage(HttpMethod.Post, "api/loans/request");

        ApplySecurityHeaders(request);

        request.Content = JsonContent.Create(body);

        using var response = await _http.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            throw new InvalidOperationException(await ReadApiErrorAsync(response));
        }

        ClearCache();
    }

    public async Task ApproveAndAssignLoanAsync(Guid loanId, MobileLoanActionDto body)
    {
        using var request = new HttpRequestMessage(HttpMethod.Patch, $"api/loans/{loanId}/approve-assign");

        ApplySecurityHeaders(request);

        request.Content = JsonContent.Create(body);

        using var response = await _http.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            throw new InvalidOperationException(await ReadApiErrorAsync(response));
        }

        ClearCache();
    }

    public async Task RejectLoanRequestAsync(Guid loanId, MobileLoanActionDto body)
    {
        using var request = new HttpRequestMessage(HttpMethod.Patch, $"api/loans/{loanId}/reject");

        ApplySecurityHeaders(request);

        request.Content = JsonContent.Create(body);

        using var response = await _http.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            throw new InvalidOperationException(await ReadApiErrorAsync(response));
        }

        ClearCache();
    }

    public async Task AssignFixedAssetAsync(Guid toolId, MobileDirectAssignmentRequest body)
    {
        using var request = new HttpRequestMessage(HttpMethod.Patch, $"api/tools/{toolId}/assign-fixed-asset");

        ApplySecurityHeaders(request);

        request.Content = JsonContent.Create(body);

        using var response = await _http.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            throw new InvalidOperationException(await ReadApiErrorAsync(response));
        }

        ClearCache();
    }
    public string ToApiUrl(string? url)
    {
        if (string.IsNullOrWhiteSpace(url))
        {
            return "#";
        }

        if (Uri.TryCreate(url, UriKind.Absolute, out var absolute))
        {
            return absolute.ToString();
        }

        var baseUri = _http.BaseAddress ?? new Uri("http://localhost:5218/");

        return new Uri(baseUri, url.TrimStart('/')).ToString();
    }

    public void ClearCache()
    {
        _toolsCache = null;
        _toolsCacheAt = null;
        _dashboardCache = null;
        _dashboardCacheAt = null;
    }

    private void ApplySecurityHeaders(HttpRequestMessage request)
    {
        var user = _auth.CurrentUser;

        if (user is null)
        {
            return;
        }

        request.Headers.Remove("X-Navi-UserName");
        request.Headers.Remove("X-Navi-RoleCode");
        request.Headers.Remove("X-Navi-Permissions");
        request.Headers.Remove("X-Navi-BranchId");
        request.Headers.Remove("X-Navi-ResponsiblePersonId");
        request.Headers.Remove("X-Navi-ResponsiblePersonName");

        request.Headers.Add("X-Navi-UserName", user.UserName);
        request.Headers.Add("X-Navi-RoleCode", user.RoleCode);
        request.Headers.Add("X-Navi-Permissions", string.Join(";", user.Permissions ?? new()));

        if (user.BranchId.HasValue)
        {
            request.Headers.Add("X-Navi-BranchId", user.BranchId.Value.ToString());
        }

        if (user.ResponsiblePersonId.HasValue)
        {
            request.Headers.Add("X-Navi-ResponsiblePersonId", user.ResponsiblePersonId.Value.ToString());
        }

        if (!string.IsNullOrWhiteSpace(user.ResponsiblePersonName))
        {
            request.Headers.Add("X-Navi-ResponsiblePersonName", user.ResponsiblePersonName);
        }
    }

    private static async Task<string> ReadApiErrorAsync(HttpResponseMessage response)
    {
        var content = await response.Content.ReadAsStringAsync();

        if (string.IsNullOrWhiteSpace(content))
        {
            return $"Error HTTP {(int)response.StatusCode}: {response.ReasonPhrase}";
        }

        try
        {
            using var doc = JsonDocument.Parse(content);

            if (doc.RootElement.TryGetProperty("message", out var message))
            {
                return message.GetString() ?? content;
            }

            if (doc.RootElement.TryGetProperty("Message", out var messageUpper))
            {
                return messageUpper.GetString() ?? content;
            }
        }
        catch
        {
            return content;
        }

        return content;
    }
}




