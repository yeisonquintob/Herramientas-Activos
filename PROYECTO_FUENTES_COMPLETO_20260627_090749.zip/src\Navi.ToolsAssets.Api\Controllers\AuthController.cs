﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;
using System.Text;
using Navi.ToolsAssets.Infrastructure.Persistence.Context;

namespace Navi.ToolsAssets.Api.Controllers;

[ApiController]
[Route("api/auth")]
public sealed class AuthController : ControllerBase
{
    private readonly NaviToolsAssetsDbContext _context;

    public AuthController(NaviToolsAssetsDbContext context)
    {
        _context = context;
    }

    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginRequest request, CancellationToken cancellationToken)
    {
        await EnsureAppUserPasswordHashColumnAsync(cancellationToken);

        var userName = request.UserName?.Trim();

        if (string.IsNullOrWhiteSpace(userName))
        {
            return BadRequest(new { Message = "Debe ingresar el documento o usuario." });
        }

        if (string.IsNullOrWhiteSpace(request.Password))
        {
            return BadRequest(new { Message = "Debe ingresar la contraseña." });
        }

        var user = await _context.AppUsers
            .Include(x => x.AppRole)
            .Include(x => x.Branch)
            .Include(x => x.ResponsiblePerson)
            .FirstOrDefaultAsync(x =>
                !x.IsDeleted &&
                x.UserName.ToLower() == userName.ToLower(),
                cancellationToken);

        if (user is null)
        {
            return Unauthorized(new { Message = "Usuario o contraseña inválidos." });
        }

        if (!user.IsActive)
        {
            return Unauthorized(new { Message = "El usuario está inactivo o bloqueado." });
        }

        if (!string.IsNullOrWhiteSpace(user.PasswordHash) &&
            !VerifyUserPassword(request.Password, user.PasswordHash))
        {
            return Unauthorized(new { Message = "Usuario o contraseña inválidos." });
        }

        if (user.AppRole is null || !user.AppRole.IsActive)
        {
            return Unauthorized(new { Message = "El usuario no tiene un rol activo asignado." });
        }

        user.LastLoginAt = DateTime.UtcNow;
        user.UpdatedAt = DateTime.UtcNow;
        user.UpdatedBy = "auth-login";

        await _context.SaveChangesAsync(cancellationToken);

        var permissions = BuildPermissions(user.AppRole.Code, user.AppRole.Permissions);

        return Ok(new LoginResponse
        {
            UserId = user.Id,
            UserName = user.UserName,
            DisplayName = user.DisplayName,
            Email = user.Email,
            Position = user.Position,
            Area = user.Area,
            RoleId = user.AppRole.Id,
            RoleCode = user.AppRole.Code,
            RoleName = user.AppRole.Name,
            BranchId = user.BranchId,
            BranchCode = user.Branch?.Code ?? "TODAS",
            BranchName = user.Branch?.Name ?? "Todas las sedes",
            ResponsiblePersonId = user.ResponsiblePersonId,
            ResponsiblePersonName = user.ResponsiblePerson?.FullName,
            Permissions = permissions,
            LastLoginAt = user.LastLoginAt
        });
    }







    [HttpGet("permissions")]
    public IActionResult GetPermissions()
    {
        return Ok(SecurityPermissions.All);
    }

        private async Task EnsureSecurityUsersPasswordSchemaAsync(CancellationToken cancellationToken)
    {
        var sql = @"
IF COL_LENGTH('Security.AppUsers', 'PasswordHash') IS NULL
BEGIN
    ALTER TABLE [Security].[AppUsers] ADD [PasswordHash] nvarchar(500) NULL;
END
";

        await _context.Database.ExecuteSqlRawAsync(sql, cancellationToken);
    }

    private static string HashPassword(string password)
    {
        var value = password.Trim();
        var bytes = SHA256.HashData(Encoding.UTF8.GetBytes(value));
        return Convert.ToHexString(bytes);
    }

    private static bool VerifyPassword(string? password, string hash)
    {
        if (string.IsNullOrWhiteSpace(password))
        {
            return false;
        }

        return string.Equals(HashPassword(password), hash, StringComparison.OrdinalIgnoreCase);
    }

        private async Task EnsureAppUserPasswordHashColumnAsync(CancellationToken cancellationToken)
    {
        var entityType = _context.Model.FindEntityType(typeof(Navi.ToolsAssets.Domain.Entities.Security.AppUser));

        var tableName = entityType?.GetTableName();

        if (string.IsNullOrWhiteSpace(tableName))
        {
            tableName = "AppUsers";
        }

        var schema = entityType?.GetSchema();

        static string SqlValue(string? value)
        {
            return (value ?? string.Empty).Replace("'", "''");
        }

        var schemaValue = SqlValue(schema);
        var tableValue = SqlValue(tableName);

        var sql = $@"
DECLARE @SchemaName sysname = NULLIF(N'{schemaValue}', N'');
DECLARE @TableName sysname = N'{tableValue}';

IF @SchemaName IS NULL
BEGIN
    SELECT TOP(1) @SchemaName = s.name
    FROM sys.tables t
    INNER JOIN sys.schemas s ON s.schema_id = t.schema_id
    WHERE t.name = @TableName;
END

IF @SchemaName IS NULL
BEGIN
    THROW 50000, 'No se encontro la tabla AppUsers en la base de datos.', 1;
END

DECLARE @QualifiedTable nvarchar(300) = QUOTENAME(@SchemaName) + N'.' + QUOTENAME(@TableName);

IF COL_LENGTH(@QualifiedTable, N'PasswordHash') IS NULL
BEGIN
    DECLARE @AlterSql nvarchar(max) = N'ALTER TABLE ' + @QualifiedTable + N' ADD [PasswordHash] nvarchar(500) NULL;';
    EXEC sp_executesql @AlterSql;
END
";

        await _context.Database.ExecuteSqlRawAsync(sql, cancellationToken);
    }

    private static string HashUserPassword(string password)
    {
        var value = password.Trim();
        var bytes = SHA256.HashData(Encoding.UTF8.GetBytes(value));
        return Convert.ToHexString(bytes);
    }

    private static bool VerifyUserPassword(string? password, string hash)
    {
        if (string.IsNullOrWhiteSpace(password))
        {
            return false;
        }

        return string.Equals(HashUserPassword(password), hash, StringComparison.OrdinalIgnoreCase);
    }
    private static List<string> BuildPermissions(string roleCode, string? permissions)
    {
        var code = roleCode.Trim().ToUpperInvariant();

        if (code is "ADMIN" or "ADMINISTRADOR")
        {
            return SecurityPermissions.All
                .Select(x => x.Code)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .OrderBy(x => x)
                .ToList();
        }

        var result = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        foreach (var permission in GetDefaultPermissionsByRole(roleCode))
        {
            result.Add(permission);
        }

        var parsed = (permissions ?? string.Empty)
            .Split(new[] { ',', ';', '\n', '\r', '|' }, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .ToList();

        foreach (var permission in parsed)
        {
            foreach (var normalized in NormalizePermission(permission))
            {
                result.Add(normalized);
            }
        }

        RemoveAdministrativePermissionsForNonAdmin(code, result);
        ApplyRoleMatrixRestrictions(code, result);

        return result
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .OrderBy(x => x)
            .ToList();
    }

    private static void ApplyRoleMatrixRestrictions(string roleCode, HashSet<string> permissions)
    {
        var code = roleCode.Trim().ToUpperInvariant();

        if (code is "TECNICO" or "TÉCNICO")
        {
            // Matriz aplicada:
            // Técnico = principalmente App Móvil.
            // No compra, no conciliación, no planes/mantenimiento formal,
            // no historial global, no configuración, no edición de activos.

            var blocked = new[]
            {
                "Dashboard.View",

                "Tools.Create",
                "Tools.Edit",
                "Tools.Delete",

                "AssetAvailability.View",
                "AssetAvailability.Edit",

                "AssetAssignment.View",
                "AssetAssignment.Assign",
                "AssetAssignment.Return",

                "TechnicalLifeRecord.Edit",
                "TechnicalLifeRecord.Export",

                "Documents.Download",
                "Documents.Delete",

                "Maintenance.View",
                "Maintenance.Request",
                "Maintenance.Execute",
                "Maintenance.Close",
                "Maintenance.Plans.View",
                "Maintenance.Plans.Manage",

                "Purchases.View",
                "Purchases.Request",
                "Purchases.Approve",
                "Purchases.Reject",

                "PhysicalCounts.View",
                "PhysicalCounts.Create",
                "PhysicalCounts.Close",

                "Reconciliation.View",
                "Reconciliation.Manage",

                "Reports.View",

                "Settings.View",
                "Settings.Manage",
                "Security.Users",
                "Security.Roles",

                "DeliveryAct.Generate",
                "FixedAssets.Disposal.Request",
                "FixedAssets.Disposal.Approve"
            };

            foreach (var permission in blocked)
            {
                permissions.Remove(permission);
            }

            permissions.Add("Tools.View");
            permissions.Add("AssetAssignment.History");
            permissions.Add("TechnicalLifeRecord.View");

            permissions.Add("Documents.View");
            permissions.Add("Documents.Upload");

            permissions.Add("Mobile.Access");
            permissions.Add("Mobile.Tools.View");
            permissions.Add("Mobile.Tools.Review");
            permissions.Add("Mobile.PreOperational.Report");
            permissions.Add("Mobile.Damage.Report");
            permissions.Add("Mobile.Loans.Request");
        }
    }

    private static void RemoveAdministrativePermissionsForNonAdmin(string roleCode, HashSet<string> permissions)
    {
        if (roleCode is "ADMIN" or "ADMINISTRADOR")
        {
            return;
        }

        permissions.Remove("Settings.View");
        permissions.Remove("Settings.Manage");
        permissions.Remove("Security.Users");
        permissions.Remove("Security.Roles");

        permissions.Remove("USERS.MANAGE");
        permissions.Remove("ROLES.MANAGE");
        permissions.Remove("SETTINGS.VIEW");
        permissions.Remove("SETTINGS.MANAGE");
        permissions.Remove("BRANCHES.MANAGE");
        permissions.Remove("WAREHOUSES.MANAGE");
        permissions.Remove("CATALOGS.MANAGE");
    }

    private static IEnumerable<string> NormalizePermission(string permission)
    {
        var value = permission.Trim();
        var code = value.ToUpperInvariant();

        if (SecurityPermissions.All.Any(x => string.Equals(x.Code, value, StringComparison.OrdinalIgnoreCase)))
        {
            yield return SecurityPermissions.All
                .First(x => string.Equals(x.Code, value, StringComparison.OrdinalIgnoreCase))
                .Code;

            yield break;
        }

        var mapped = code switch
        {
            "DASHBOARD.VIEW" => new[] { "Dashboard.View" },
            "DASHBOARD.EXECUTIVE" => new[] { "Dashboard.View" },
            "DASHBOARD.REFRESH" => new[] { "Dashboard.View" },

            "INVENTORY.VIEW" => new[] { "Tools.View" },
            "INVENTORY.CREATE" => new[] { "Tools.Create" },
            "INVENTORY.EDIT" => new[] { "Tools.Edit" },
            "INVENTORY.DELETE" => new[] { "Tools.Delete" },
            "INVENTORY.EXPORT" => new[] { "Tools.View", "Reports.View" },

            "LOCATION.VIEW" => new[] { "AssetAvailability.View" },
            "LOCATION.MANAGE" => new[] { "AssetAvailability.View", "AssetAvailability.Edit" },

            "ASSIGNMENT.VIEW" => new[] { "AssetAssignment.View" },
            "ASSIGNMENT.CREATE" => new[] { "AssetAssignment.View", "AssetAssignment.Assign" },
            "ASSIGNMENT.CLOSE" => new[] { "AssetAssignment.View", "AssetAssignment.Return" },
            "ASSIGNMENT.HISTORY" => new[] { "AssetAssignment.History" },

            "LIFERECORD.VIEW" => new[] { "TechnicalLifeRecord.View" },
            "LIFERECORD.EDIT" => new[] { "TechnicalLifeRecord.View", "TechnicalLifeRecord.Edit" },
            "LIFERECORD.EXPORT" => new[] { "TechnicalLifeRecord.View", "TechnicalLifeRecord.Export" },
            "LIFERECORD.EVENTS" => new[] { "TechnicalLifeRecord.View" },

            "MAINTENANCE.VIEW" => new[] { "Maintenance.View" },
            "MAINTENANCE.REQUEST" => new[] { "Maintenance.View", "Maintenance.Request" },
            "MAINTENANCE.SCHEDULE" => new[] { "Maintenance.View", "Maintenance.Request" },
            "MAINTENANCE.EXECUTE" => new[] { "Maintenance.View", "Maintenance.Execute" },
            "MAINTENANCE.APPROVE" => new[] { "Maintenance.View", "Maintenance.Close" },

            "LOAN.VIEW" => new[] { "AssetAssignment.View", "AssetAssignment.History" },
            "LOAN.CREATE" => new[] { "Mobile.Loans.Request" },
            "LOAN.DELIVER" => new[] { "AssetAssignment.View", "AssetAssignment.Assign" },
            "LOAN.RETURN" => new[] { "AssetAssignment.View", "AssetAssignment.Return" },
            "LOAN.APPROVE" => new[] { "AssetAssignment.View", "AssetAssignment.Assign" },

            "DAMAGE.VIEW" => new[] { "Mobile.Damage.Report" },
            "DAMAGE.REPORT" => new[] { "Mobile.Damage.Report" },
            "DAMAGE.EDIT" => new[] { "Maintenance.View", "Maintenance.Execute" },
            "DAMAGE.CLOSE" => new[] { "Maintenance.View", "Maintenance.Close" },

            "PHYSICALCOUNT.VIEW" => new[] { "PhysicalCounts.View" },
            "PHYSICALCOUNT.CREATE" => new[] { "PhysicalCounts.View", "PhysicalCounts.Create" },
            "PHYSICALCOUNT.EXECUTE" => new[] { "Mobile.Tools.Review" },
            "PHYSICALCOUNT.CLOSE" => new[] { "PhysicalCounts.View", "PhysicalCounts.Close" },

            "DOCUMENT.VIEW" => new[] { "Documents.View" },
            "DOCUMENT.UPLOAD" => new[] { "Documents.View", "Documents.Upload" },
            "DOCUMENT.DOWNLOAD" => new[] { "Documents.View", "Documents.Download" },
            "DOCUMENT.DELETE" => new[] { "Documents.View", "Documents.Delete" },

            "PURCHASE.VIEW" => new[] { "Purchases.View" },
            "PURCHASE.REQUEST" => new[] { "Purchases.View", "Purchases.Request" },
            "PURCHASE.APPROVE" => new[] { "Purchases.View", "Purchases.Approve" },
            "PURCHASE.REJECT" => new[] { "Purchases.View", "Purchases.Reject" },

            "REPORT.VIEW" => new[] { "Reports.View" },
            "REPORT.EXPORT" => new[] { "Reports.View" },
            "AUDIT.VIEW" => new[] { "Reports.View" },

            "RECONCILIATION.VIEW" => new[] { "Reconciliation.View" },
            "RECONCILIATION.MANAGE" => new[] { "Reconciliation.View", "Reconciliation.Manage" },

            "SETTINGS.VIEW" => new[] { "Settings.View" },
            "SETTINGS.MANAGE" => new[] { "Settings.View", "Settings.Manage" },
            "USERS.MANAGE" => new[] { "Security.Users" },
            "ROLES.MANAGE" => new[] { "Security.Roles" },
            "BRANCHES.MANAGE" => new[] { "Settings.View", "Settings.Manage" },
            "WAREHOUSES.MANAGE" => new[] { "Settings.View", "Settings.Manage" },
            "CATALOGS.MANAGE" => new[] { "Settings.View", "Settings.Manage" },

            _ => new[] { value }
        };

        foreach (var item in mapped)
        {
            yield return item;
        }
    }

    private static List<string> GetDefaultPermissionsByRole(string roleCode)
    {
        var code = roleCode.Trim().ToUpperInvariant();

        if (code is "ADMIN" or "ADMINISTRADOR")
        {
            return SecurityPermissions.All.Select(x => x.Code).ToList();
        }

        if (code is "GERENCIAL" or "GERENCIA" or "AUDITOR" or "AUDITORIA")
        {
            return new()
            {
                "Dashboard.View",
                "Tools.View",
                "AssetAvailability.View",
                "AssetAssignment.View",
                "AssetAssignment.History",
                "TechnicalLifeRecord.View",
                "TechnicalLifeRecord.Export",
                "Documents.View",
                "Documents.Download",
                "Maintenance.View",
                "Maintenance.Close",
                "Purchases.View",
                "Purchases.Approve",
                "Purchases.Reject",
                "PhysicalCounts.View",
                "Reports.View"
            };
        }

        if (code is "HERRAMIENTAS" or "HERRAMENTERO" or "HERRAMIENTA" or "HERRAMIENTERO")
        {
            return new()
            {
                "Dashboard.View",
                "Tools.View",
                "Tools.Create",
                "Tools.Edit",
                "AssetAvailability.View",
                "AssetAvailability.Edit",
                "AssetAssignment.View",
                "AssetAssignment.Assign",
                "AssetAssignment.Return",
                "AssetAssignment.History",
                "TechnicalLifeRecord.View",
                "TechnicalLifeRecord.Edit",
                "TechnicalLifeRecord.Export",
                "Documents.View",
                "Documents.Upload",
                "Documents.Download",
                "Maintenance.View",
                "Maintenance.Request",
                "Purchases.View",
                "Purchases.Request",
                "PhysicalCounts.View",
                "PhysicalCounts.Create",
                "Reports.View",
                "Mobile.Access",
                "Mobile.Tools.View",
                "Mobile.Tools.Review",
                "Mobile.PreOperational.Report",
                "Mobile.Damage.Report",
                "DeliveryAct.Generate",
                "FixedAssets.Disposal.Request"
            };
        }

        if (code is "ING_SERVICIOS" or "INGENIERO_SERVICIOS" or "ING_SERVICIO" or "INGENIERIA_SERVICIOS")
        {
            return new()
            {
                "Dashboard.View",
                "Tools.View",
                "AssetAvailability.View",
                "AssetAssignment.View",
                "AssetAssignment.History",
                "TechnicalLifeRecord.View",
                "TechnicalLifeRecord.Export",
                "Documents.View",
                "Documents.Download",
                "Maintenance.View",
                "Maintenance.Close",
                "Purchases.View",
                "Purchases.Approve",
                "Purchases.Reject",
                "PhysicalCounts.View",
                "Reports.View",
                "Mobile.Access",
                "Mobile.Tools.View",
                "Mobile.Tools.Review",
                "Mobile.PreOperational.Report",
                "Mobile.Damage.Report",
                "FixedAssets.Disposal.Approve"
            };
        }

        if (code is "COORDINADOR_TALLER" or "COORDINADOR_DE_TALLER" or "COORD_TALLER" or "SEDE" or "RESPONSABLE_SEDE")
        {
            return new()
            {
                "Dashboard.View",
                "Tools.View",
                "Tools.Create",
                "Tools.Edit",
                "AssetAvailability.View",
                "AssetAvailability.Edit",
                "AssetAssignment.View",
                "AssetAssignment.Assign",
                "AssetAssignment.Return",
                "AssetAssignment.History",
                "TechnicalLifeRecord.View",
                "TechnicalLifeRecord.Edit",
                "TechnicalLifeRecord.Export",
                "Documents.View",
                "Documents.Upload",
                "Documents.Download",
                "Documents.Delete",
                "Maintenance.View",
                "Maintenance.Request",
                "Maintenance.Execute",
                "Maintenance.Close",
                "Purchases.View",
                "Purchases.Request",
                "Purchases.Approve",
                "Purchases.Reject",
                "PhysicalCounts.View",
                "PhysicalCounts.Create",
                "PhysicalCounts.Close",
                "Reports.View",
                "Mobile.Access",
                "Mobile.Tools.View",
                "Mobile.Tools.Review",
                "Mobile.PreOperational.Report",
                "Mobile.Damage.Report",
                "DeliveryAct.Generate",
                "FixedAssets.Disposal.Request",
                "FixedAssets.Disposal.Approve"
            };
        }

        if (code is "TECNICO" or "TÉCNICO")
        {
            return new()
            {
                "Tools.View",
                "AssetAssignment.History",
                "TechnicalLifeRecord.View",
                "Documents.View",
                "Documents.Upload",
                "Mobile.Access",
                "Mobile.Tools.View",
                "Mobile.Tools.Review",
                "Mobile.PreOperational.Report",
                "Mobile.Damage.Report",
                "Mobile.Loans.Request"
            };
        }

        return new()
        {
            "Dashboard.View"
        };
    }
}

public sealed class LoginRequest
{
    public string? UserName { get; set; }

    public string? Password { get; set; }
}

public sealed class LoginResponse
{
    public Guid UserId { get; set; }

    public string UserName { get; set; } = string.Empty;

    public string DisplayName { get; set; } = string.Empty;

    public string? Email { get; set; }

    public string? Position { get; set; }

    public string? Area { get; set; }

    public Guid RoleId { get; set; }

    public string RoleCode { get; set; } = string.Empty;

    public string RoleName { get; set; } = string.Empty;

    public Guid? BranchId { get; set; }

    public string BranchCode { get; set; } = "TODAS";

    public string BranchName { get; set; } = "Todas las sedes";

    public Guid? ResponsiblePersonId { get; set; }

    public string? ResponsiblePersonName { get; set; }

    public List<string> Permissions { get; set; } = new();

    public DateTime? LastLoginAt { get; set; }
}

public sealed record PermissionInfo(string Code, string Module, string Action, string Description);

public static class SecurityPermissions
{
    public static readonly List<PermissionInfo> All = new()
    {
        new("Dashboard.View", "Dashboard", "Ver", "Ver dashboard ejecutivo."),

        new("Tools.View", "Inventario AF", "Ver", "Ver inventario de herramientas y activos."),
        new("Tools.Create", "Inventario AF", "Crear", "Crear herramientas o activos."),
        new("Tools.Edit", "Inventario AF", "Editar", "Editar herramientas o activos."),
        new("Tools.Delete", "Inventario AF", "Eliminar", "Eliminar herramientas o activos."),

        new("AssetAvailability.View", "Disponible y ubicación", "Ver", "Ver disponibilidad y ubicación."),
        new("AssetAvailability.Edit", "Disponible y ubicación", "Editar", "Cambiar disponibilidad, sede o ubicación."),

        new("AssetAssignment.View", "Asignar AF", "Ver", "Ver módulo de asignaciones."),
        new("AssetAssignment.Assign", "Asignar AF", "Asignar", "Asignar activos a responsables."),
        new("AssetAssignment.Return", "Asignar AF", "Regresar", "Regresar activos a almacén/taller."),
        new("AssetAssignment.History", "Asignar AF", "Historial", "Ver historial de asignaciones."),

        new("TechnicalLifeRecord.View", "Hoja de vida", "Ver", "Ver hoja de vida técnica."),
        new("TechnicalLifeRecord.Edit", "Hoja de vida", "Editar", "Editar datos técnicos de hoja de vida."),
        new("TechnicalLifeRecord.Export", "Hoja de vida", "Exportar", "Exportar hoja de vida a PDF o Excel."),

        new("Documents.View", "Documentos", "Ver", "Ver documentos y evidencias."),
        new("Documents.Upload", "Documentos", "Cargar", "Cargar documentos y evidencias."),
        new("Documents.Download", "Documentos", "Descargar", "Descargar documentos."),
        new("Documents.Delete", "Documentos", "Eliminar", "Eliminar documentos."),

        new("Maintenance.View", "Mantenimiento", "Ver", "Ver mantenimientos."),
        new("Maintenance.Request", "Mantenimiento", "Solicitar", "Solicitar mantenimiento."),
        new("Maintenance.Execute", "Mantenimiento", "Ejecutar", "Registrar ejecución de mantenimiento."),
        new("Maintenance.Close", "Mantenimiento", "Cerrar", "Cerrar mantenimiento."),

        new("Purchases.View", "Compras AF", "Ver", "Ver solicitudes de compra."),
        new("Purchases.Request", "Compras AF", "Solicitar", "Solicitar compra de activo fijo."),
        new("Purchases.Approve", "Compras AF", "Aprobar", "Aprobar compra de activo fijo."),
        new("Purchases.Reject", "Compras AF", "Rechazar", "Rechazar compra de activo fijo."),

        new("PhysicalCounts.View", "Tomas físicas", "Ver", "Ver tomas físicas."),
        new("PhysicalCounts.Create", "Tomas físicas", "Crear", "Crear toma física."),
        new("PhysicalCounts.Close", "Tomas físicas", "Cerrar", "Cerrar toma física."),

        new("SafePractices.View", "Prácticas seguras", "Ver", "Ver prácticas seguras."),
        new("SafePractices.Manage", "Prácticas seguras", "Administrar", "Administrar prácticas seguras."),

        new("Reports.View", "Reportes", "Ver", "Ver reportes."),

        new("Reconciliation.View", "Conciliación", "Ver", "Ver conciliación administrativa."),
        new("Reconciliation.Manage", "Conciliación", "Gestionar", "Aclarar, aprobar creación, conciliar o rechazar."),

        new("Settings.View", "Configuración", "Ver", "Ver configuración."),
        new("Settings.Manage", "Configuración", "Administrar", "Administrar configuración base."),

        new("Security.Users", "Seguridad", "Usuarios", "Administrar usuarios."),
        new("Security.Roles", "Seguridad", "Roles", "Administrar roles y permisos.")
    };
}




















