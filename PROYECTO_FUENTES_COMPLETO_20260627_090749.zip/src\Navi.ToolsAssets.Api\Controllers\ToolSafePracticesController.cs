using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Navi.ToolsAssets.Domain.Entities.Inventory;
using Navi.ToolsAssets.Domain.Entities.LifeCycles;
using Navi.ToolsAssets.Domain.Entities.Safety;
using Navi.ToolsAssets.Infrastructure.Persistence.Context;

namespace Navi.ToolsAssets.Api.Controllers;

[ApiController]
[Route("api/tools")]
public class ToolSafePracticesController : ControllerBase
{
    private readonly NaviToolsAssetsDbContext _context;

    public ToolSafePracticesController(NaviToolsAssetsDbContext context)
    {
        _context = context;
    }


    [HttpGet("{id:guid}/safe-practices")]
    public async Task<IActionResult> GetSafePracticesByToolId(Guid id, CancellationToken cancellationToken)
    {
        var toolExists = await _context.ToolAssets
            .AnyAsync(x => x.Id == id, cancellationToken);

        if (!toolExists)
        {
            return NotFound(new { Message = "No se encontr� la herramienta." });
        }

        var practices = await _context.ToolSafePractices
            .AsNoTracking()
            .Where(x => x.ToolAssetId == id && x.IsActive)
            .OrderBy(x => x.SortOrder)
            .ThenBy(x => x.PracticeName)
            .Select(x => new
            {
                x.Id,
                x.ToolAssetId,
                x.PracticeName,
                x.Description,
                x.SortOrder,
                x.IsActive,
                x.CreatedAt,
                x.CreatedBy,
                x.UpdatedAt,
                x.UpdatedBy
            })
            .ToListAsync(cancellationToken);

        return Ok(practices);
    }

    [HttpGet("by-code/{internalCode}/safe-practices")]
    public async Task<IActionResult> GetSafePracticesByToolCode(string internalCode, CancellationToken cancellationToken)
    {
        var normalizedCode = internalCode.Trim().ToUpperInvariant();

        var tool = await _context.ToolAssets
            .AsNoTracking()
            .FirstOrDefaultAsync(x => x.InternalCode == normalizedCode, cancellationToken);

        if (tool is null)
        {
            return NotFound(new { Message = "No se encontr� la herramienta." });
        }

        var practices = await _context.ToolSafePractices
            .AsNoTracking()
            .Where(x => x.ToolAssetId == tool.Id && x.IsActive)
            .OrderBy(x => x.SortOrder)
            .ThenBy(x => x.PracticeName)
            .Select(x => new
            {
                x.Id,
                x.ToolAssetId,
                x.PracticeName,
                x.Description,
                x.SortOrder,
                x.IsActive,
                x.CreatedAt,
                x.CreatedBy,
                x.UpdatedAt,
                x.UpdatedBy
            })
            .ToListAsync(cancellationToken);

        return Ok(practices);
    }
    [HttpPost("{id:guid}/safe-practices")]
    public async Task<IActionResult> Create(Guid id, [FromBody] CreateToolSafePracticeRequest request, CancellationToken cancellationToken)
    {
        var tool = await _context.ToolAssets
            .FirstOrDefaultAsync(x => x.Id == id, cancellationToken);

        if (tool is null)
        {
            return NotFound(new { Message = "No se encontr� la herramienta." });
        }

        return await CreateSafePracticeAsync(tool, request, cancellationToken);
    }

    [HttpPost("by-code/{internalCode}/safe-practices")]
    public async Task<IActionResult> CreateByCode(string internalCode, [FromBody] CreateToolSafePracticeRequest request, CancellationToken cancellationToken)
    {
        var normalizedCode = internalCode.Trim().ToUpperInvariant();

        var tool = await _context.ToolAssets
            .FirstOrDefaultAsync(x => x.InternalCode == normalizedCode, cancellationToken);

        if (tool is null)
        {
            return NotFound(new { Message = "No se encontr� la herramienta." });
        }

        return await CreateSafePracticeAsync(tool, request, cancellationToken);
    }

    [HttpPost("{id:guid}/safe-practices/defaults")]
    public async Task<IActionResult> CreateDefaults(Guid id, CancellationToken cancellationToken)
    {
        var tool = await GetToolWithSafePracticesAsync(id, cancellationToken);

        if (tool is null)
        {
            return NotFound(new { Message = "No se encontr� la herramienta." });
        }

        return await CreateDefaultSafePracticesAsync(tool, cancellationToken);
    }

    [HttpPost("by-code/{internalCode}/safe-practices/defaults")]
    public async Task<IActionResult> CreateDefaultsByCode(string internalCode, CancellationToken cancellationToken)
    {
        var normalizedCode = internalCode.Trim().ToUpperInvariant();

        var tool = await _context.ToolAssets
            .Include(x => x.ToolType)
            .Include(x => x.ToolCategory)
            .Include(x => x.SafePractices)
            .FirstOrDefaultAsync(x => x.InternalCode == normalizedCode, cancellationToken);

        if (tool is null)
        {
            return NotFound(new { Message = "No se encontr� la herramienta." });
        }

        return await CreateDefaultSafePracticesAsync(tool, cancellationToken);
    }


    [HttpPut("safe-practices/{safePracticeId:guid}")]
    public async Task<IActionResult> UpdateSafePractice(Guid safePracticeId, [FromBody] UpdateToolSafePracticeRequest request, CancellationToken cancellationToken)
    {
        var practice = await _context.ToolSafePractices
            .FirstOrDefaultAsync(x => x.Id == safePracticeId, cancellationToken);

        if (practice is null)
        {
            return NotFound(new { Message = "No se encontr� la pr�ctica segura." });
        }

        if (string.IsNullOrWhiteSpace(request.PracticeName))
        {
            return BadRequest(new { Message = "El nombre de la pr�ctica segura es obligatorio." });
        }

        if (string.IsNullOrWhiteSpace(request.Description))
        {
            return BadRequest(new { Message = "La descripci�n de la pr�ctica segura es obligatoria." });
        }

        var user = string.IsNullOrWhiteSpace(request.UpdatedBy) ? "yquinto" : request.UpdatedBy.Trim();

        var previousValue = $"{practice.SortOrder}. {practice.PracticeName}";

        practice.PracticeName = request.PracticeName.Trim();
        practice.Description = request.Description.Trim();
        practice.SortOrder = request.SortOrder;
        practice.UpdatedAt = DateTime.UtcNow;
        practice.UpdatedBy = user;

        _context.Set<ToolLifeCycleEvent>().Add(new ToolLifeCycleEvent
        {
            ToolAssetId = practice.ToolAssetId,
            EventType = "SafePracticeUpdated",
            Title = "Pr�ctica segura actualizada",
            Description = $"Se actualiz� la pr�ctica segura: {practice.PracticeName}.",
            PreviousValue = previousValue,
            NewValue = $"{practice.SortOrder}. {practice.PracticeName}",
            RegisteredBy = user,
            CreatedBy = user
        });

        await _context.SaveChangesAsync(cancellationToken);

        return Ok(new
        {
            Message = "Pr�ctica segura actualizada correctamente.",
            practice.Id,
            practice.ToolAssetId,
            practice.PracticeName,
            practice.Description,
            practice.SortOrder
        });
    }

    [HttpDelete("safe-practices/{safePracticeId:guid}")]
    public async Task<IActionResult> DeleteSafePractice(Guid safePracticeId, [FromQuery] string? deletedBy, CancellationToken cancellationToken)
    {
        var practice = await _context.ToolSafePractices
            .FirstOrDefaultAsync(x => x.Id == safePracticeId, cancellationToken);

        if (practice is null)
        {
            return NotFound(new { Message = "No se encontr� la pr�ctica segura." });
        }

        var user = string.IsNullOrWhiteSpace(deletedBy) ? "yquinto" : deletedBy.Trim();

        practice.IsActive = false;
        practice.IsDeleted = true;
        practice.UpdatedAt = DateTime.UtcNow;
        practice.UpdatedBy = user;

        _context.Set<ToolLifeCycleEvent>().Add(new ToolLifeCycleEvent
        {
            ToolAssetId = practice.ToolAssetId,
            EventType = "SafePracticeDeleted",
            Title = "Pr�ctica segura desactivada",
            Description = $"Se desactiv� la pr�ctica segura: {practice.PracticeName}.",
            PreviousValue = practice.PracticeName,
            NewValue = "Desactivada",
            RegisteredBy = user,
            CreatedBy = user
        });

        await _context.SaveChangesAsync(cancellationToken);

        return Ok(new
        {
            Message = "Pr�ctica segura desactivada correctamente.",
            practice.Id,
            practice.ToolAssetId,
            practice.PracticeName
        });
    }
    private async Task<ToolAsset?> GetToolWithSafePracticesAsync(Guid id, CancellationToken cancellationToken)
    {
        return await _context.ToolAssets
            .Include(x => x.ToolType)
            .Include(x => x.ToolCategory)
            .Include(x => x.SafePractices)
            .FirstOrDefaultAsync(x => x.Id == id, cancellationToken);
    }

    private async Task<IActionResult> CreateSafePracticeAsync(ToolAsset tool, CreateToolSafePracticeRequest request, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(request.PracticeName))
        {
            return BadRequest(new { Message = "El nombre de la pr�ctica segura es obligatorio." });
        }

        if (string.IsNullOrWhiteSpace(request.Description))
        {
            return BadRequest(new { Message = "La descripci�n de la pr�ctica segura es obligatoria." });
        }

        var practice = new ToolSafePractice
        {
            ToolAssetId = tool.Id,
            PracticeName = request.PracticeName.Trim(),
            Description = request.Description.Trim(),
            SortOrder = request.SortOrder,
            CreatedBy = string.IsNullOrWhiteSpace(request.CreatedBy) ? "yquinto" : request.CreatedBy
        };

        _context.ToolSafePractices.Add(practice);

        _context.Set<ToolLifeCycleEvent>().Add(new ToolLifeCycleEvent
        {
            ToolAssetId = tool.Id,
            EventType = "SafePracticeCreated",
            Title = "Pr�ctica segura registrada",
            Description = $"Se registr� la pr�ctica segura: {practice.PracticeName}.",
            NewValue = practice.PracticeName,
            RegisteredBy = practice.CreatedBy,
            CreatedBy = practice.CreatedBy
        });

        await _context.SaveChangesAsync(cancellationToken);

        return Ok(new
        {
            Message = "Pr�ctica segura creada correctamente.",
            practice.Id,
            practice.ToolAssetId,
            practice.PracticeName,
            practice.Description,
            practice.SortOrder
        });
    }

    private async Task<IActionResult> CreateDefaultSafePracticesAsync(ToolAsset tool, CancellationToken cancellationToken)
    {
        var defaults = GetDefaultSafePractices(tool);

        var existingNames = tool.SafePractices
            .Where(x => !x.IsDeleted)
            .Select(x => x.PracticeName.Trim().ToUpperInvariant())
            .ToHashSet();

        var created = new List<ToolSafePractice>();

        foreach (var item in defaults)
        {
            var normalizedName = item.PracticeName.Trim().ToUpperInvariant();

            if (existingNames.Contains(normalizedName))
            {
                continue;
            }

            var practice = new ToolSafePractice
            {
                ToolAssetId = tool.Id,
                PracticeName = item.PracticeName,
                Description = item.Description,
                SortOrder = item.SortOrder,
                CreatedBy = "yquinto"
            };

            _context.ToolSafePractices.Add(practice);
            created.Add(practice);
        }

        if (created.Count > 0)
        {
            _context.Set<ToolLifeCycleEvent>().Add(new ToolLifeCycleEvent
            {
                ToolAssetId = tool.Id,
                EventType = "DefaultSafePracticesCreated",
                Title = "Pr�cticas seguras predeterminadas registradas",
                Description = $"Se registraron {created.Count} pr�cticas seguras predeterminadas.",
                NewValue = string.Join(", ", created.Select(x => x.PracticeName)),
                RegisteredBy = "yquinto",
                CreatedBy = "yquinto"
            });
        }

        await _context.SaveChangesAsync(cancellationToken);

        return Ok(new
        {
            Message = created.Count == 0
                ? "La herramienta ya ten�a registradas las pr�cticas seguras predeterminadas."
                : "Pr�cticas seguras predeterminadas creadas correctamente.",
            ToolId = tool.Id,
            tool.InternalCode,
            CreatedCount = created.Count,
            Practices = created
                .OrderBy(x => x.SortOrder)
                .Select(x => new
                {
                    x.Id,
                    x.PracticeName,
                    x.Description,
                    x.SortOrder
                })
                .ToList()
        });
    }

    private static List<DefaultSafePracticeItem> GetDefaultSafePractices(ToolAsset tool)
    {
        var text = $"{tool.InternalCode} {tool.Name} {tool.Description} {tool.ToolType?.Name} {tool.ToolCategory?.Name}".ToUpperInvariant();

        if (text.Contains("COMPUTADOR") || text.Contains("ESCANER") || text.Contains("ESC�NER") || text.Contains("SCANNER"))
        {
            return new List<DefaultSafePracticeItem>
            {
                new(1, "Protecci�n contra sobrecalentamiento", "Asegurar que el computador tenga suficiente ventilaci�n y no se bloquee su sistema de refrigeraci�n."),
                new(2, "Uso en superficies planas", "Colocar el equipo en superficies estables y planas para evitar ca�das o da�os."),
                new(3, "Conexi�n segura a redes", "Usar conexiones Wi-Fi seguras o cables certificados para evitar interferencias o p�rdida de datos durante el escaneo."),
                new(4, "Protecci�n contra descargas el�ctricas", "Utilizar protector de sobrecarga para evitar da�os por picos de corriente."),
                new(5, "Evitar exposici�n a l�quidos", "Mantener el computador alejado de l�quidos y polvo que puedan da�ar sus componentes."),
                new(6, "Uso de antivirus y software de seguridad", "Instalar y actualizar regularmente software antivirus para proteger los datos escaneados."),
                new(7, "Copia de seguridad de datos", "Realizar copias de seguridad peri�dicas de los datos escaneados para evitar p�rdidas."),
                new(8, "Mantenimiento regular", "Limpiar y revisar el equipo regularmente para asegurar su buen funcionamiento y prevenir fallas."),
                new(9, "Protecci�n de la pantalla", "Utilizar protectores de pantalla o fundas para evitar rayaduras y da�os f�sicos."),
                new(10, "Carga adecuada", "Utilizar cargadores certificados y evitar sobrecargar la bater�a."),
                new(11, "Desconexi�n segura de dispositivos", "Desconectar adecuadamente esc�neres, memorias USB u otros dispositivos externos para evitar da�os."),
                new(12, "Revisi�n de software y actualizaciones", "Mantener actualizado el software del esc�ner y del sistema operativo para un rendimiento �ptimo.")
            };
        }

        if (text.Contains("GATO") || text.Contains("PLUMA") || text.Contains("HIDRAULICO") || text.Contains("HIDR�ULICO"))
        {
            return new List<DefaultSafePracticeItem>
            {
                new(1, "Inspecci�n previa al uso", "Verifica el estado de herramientas, mangueras y conexiones para detectar grietas, fugas o desgaste antes de usarlas."),
                new(2, "Uso de EPP", "Usa gafas de seguridad, guantes resistentes al aceite, protecci�n auditiva y calzado con punta reforzada y suela antideslizante."),
                new(3, "Procedimientos de operaci�n", "Aseg�rate de que las conexiones est�n firmes, no excedas la presi�n recomendada y mant�n las mangueras alejadas de bordes afilados o superficies calientes."),
                new(4, "Posici�n segura", "Mant�n una postura estable, limpia tu �rea de trabajo y evita colocarte frente a herramientas presurizadas."),
                new(5, "Mantenimiento regular", "Realiza inspecciones peri�dicas, reemplaza componentes desgastados y utiliza repuestos recomendados por el fabricante."),
                new(6, "Prevenci�n de fugas", "Nunca uses las manos para buscar fugas; utiliza cart�n o papel y rep�ralas solo cuando el sistema est� despresurizado."),
                new(7, "Capacitaci�n y se�alizaci�n", "Capacita al personal en el uso seguro de herramientas y coloca se�alizaci�n de advertencia en las �reas de trabajo."),
                new(8, "Despresurizaci�n al finalizar", "Antes de desconectar herramientas, libera la presi�n del sistema. Nunca realices ajustes mientras el equipo est� presurizado."),
                new(9, "Almacenamiento adecuado", "Guarda herramientas y mangueras en un lugar limpio y seco, evitando doblarlas de forma incorrecta.")
            };
        }

        return new List<DefaultSafePracticeItem>
        {
            new(1, "Inspecci�n previa al uso", "Verificar el estado general de la herramienta antes de utilizarla."),
            new(2, "Uso de elementos de protecci�n personal", "Utilizar los elementos de protecci�n personal requeridos para la operaci�n."),
            new(3, "Uso correcto de la herramienta", "Operar la herramienta �nicamente para las actividades para las que fue dise�ada."),
            new(4, "Reporte de novedades", "Reportar da�os, fallas o condiciones inseguras antes y despu�s del uso."),
            new(5, "Limpieza y almacenamiento", "Limpiar la herramienta despu�s del uso y almacenarla en el lugar asignado.")
        };
    }

    private sealed record DefaultSafePracticeItem(int SortOrder, string PracticeName, string Description);
}

public sealed class CreateToolSafePracticeRequest
{
    public string PracticeName { get; set; } = string.Empty;

    public string Description { get; set; } = string.Empty;

    public int SortOrder { get; set; }

    public string? CreatedBy { get; set; }
}


public sealed class UpdateToolSafePracticeRequest
{
    public string PracticeName { get; set; } = string.Empty;

    public string Description { get; set; } = string.Empty;

    public int SortOrder { get; set; }

    public string? UpdatedBy { get; set; }
}
