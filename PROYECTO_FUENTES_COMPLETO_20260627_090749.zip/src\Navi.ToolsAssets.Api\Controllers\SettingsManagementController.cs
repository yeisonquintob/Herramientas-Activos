﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;
using System.Text;
using Navi.ToolsAssets.Domain.Entities.Organization;
using Navi.ToolsAssets.Domain.Entities.Configuration;
using Navi.ToolsAssets.Domain.Entities.Inventory;
using Navi.ToolsAssets.Domain.Entities.Security;
using Navi.ToolsAssets.Infrastructure.Persistence.Context;

namespace Navi.ToolsAssets.Api.Controllers;

[ApiController]
[Route("api/settings")]
public class SettingsManagementController : ControllerBase
{
    private readonly NaviToolsAssetsDbContext _context;

    public SettingsManagementController(NaviToolsAssetsDbContext context)
    {
        _context = context;
    }

    // =========================================================
    // ROLES
    // =========================================================

    [HttpGet("roles")]
    public async Task<IActionResult> GetRoles(CancellationToken cancellationToken)
    {
        var roles = await _context.AppRoles
            .AsNoTracking()
            .Where(x => !x.IsDeleted)
            .OrderBy(x => x.Code)
            .Select(x => new
            {
                x.Id,
                x.Code,
                x.Name,
                x.Description,
                x.Permissions,
                x.IsActive
            })
            .ToListAsync(cancellationToken);

        return Ok(roles);
    }

    [HttpPost("roles")]
    public async Task<IActionResult> CreateRole([FromBody] SaveRoleRequest request, CancellationToken cancellationToken)
    {
        var code = NormalizeCode(request.Code);

        if (string.IsNullOrWhiteSpace(code) || string.IsNullOrWhiteSpace(request.Name))
        {
            return BadRequest(new { Message = "Código y nombre son obligatorios." });
        }

        var exists = await _context.AppRoles
            .AnyAsync(x => x.Code == code && !x.IsDeleted, cancellationToken);

        if (exists)
        {
            return Conflict(new { Message = $"Ya existe un rol con código {code}." });
        }

        var role = new AppRole
        {
            Code = code,
            Name = request.Name.Trim(),
            Description = request.Description?.Trim(),
            Permissions = request.Permissions?.Trim(),
            IsActive = request.IsActive ?? true,
            CreatedAt = DateTime.UtcNow,
            CreatedBy = request.ChangedBy ?? "settings"
        };

        _context.AppRoles.Add(role);
        await _context.SaveChangesAsync(cancellationToken);

        return Ok(new { role.Id, Message = "Rol creado correctamente." });
    }

    [HttpPut("roles/{id:guid}")]
    public async Task<IActionResult> UpdateRole(Guid id, [FromBody] SaveRoleRequest request, CancellationToken cancellationToken)
    {
        var role = await _context.AppRoles.FirstOrDefaultAsync(x => x.Id == id && !x.IsDeleted, cancellationToken);

        if (role is null)
        {
            return NotFound(new { Message = "No se encontró el rol." });
        }

        var code = NormalizeCode(request.Code);

        if (string.IsNullOrWhiteSpace(code) || string.IsNullOrWhiteSpace(request.Name))
        {
            return BadRequest(new { Message = "Código y nombre son obligatorios." });
        }

        var duplicated = await _context.AppRoles
            .AnyAsync(x => x.Id != id && x.Code == code && !x.IsDeleted, cancellationToken);

        if (duplicated)
        {
            return Conflict(new { Message = $"Ya existe otro rol con código {code}." });
        }

        role.Code = code;
        role.Name = request.Name.Trim();
        role.Description = request.Description?.Trim();
        role.Permissions = request.Permissions?.Trim();
        role.IsActive = request.IsActive ?? role.IsActive;
        role.UpdatedAt = DateTime.UtcNow;
        role.UpdatedBy = request.ChangedBy ?? "settings";

        await _context.SaveChangesAsync(cancellationToken);

        return Ok(new { Message = "Rol actualizado correctamente." });
    }

    [HttpDelete("roles/{id:guid}")]
    public async Task<IActionResult> DeleteRole(Guid id, [FromQuery] string? changedBy, CancellationToken cancellationToken)
    {
        var role = await _context.AppRoles.FirstOrDefaultAsync(x => x.Id == id && !x.IsDeleted, cancellationToken);

        if (role is null)
        {
            return NotFound(new { Message = "No se encontró el rol." });
        }

        var hasUsers = await _context.AppUsers.AnyAsync(x => x.AppRoleId == id && !x.IsDeleted, cancellationToken);

        if (hasUsers)
        {
            return BadRequest(new { Message = "No se puede eliminar el rol porque tiene usuarios asociados." });
        }

        role.IsDeleted = true;
        role.IsActive = false;
        role.UpdatedAt = DateTime.UtcNow;
        role.UpdatedBy = changedBy ?? "settings";

        await _context.SaveChangesAsync(cancellationToken);

        return Ok(new { Message = "Rol eliminado correctamente." });
    }

    // =========================================================
    // USUARIOS
    // =========================================================

    [HttpGet("users")]
    public async Task<IActionResult> GetUsers(CancellationToken cancellationToken)
    {
        var users = await _context.AppUsers
            .AsNoTracking()
            .Include(x => x.AppRole)
            .Include(x => x.Branch)
            .Where(x => !x.IsDeleted)
            .OrderBy(x => x.UserName)
            .Select(x => new
            {
                x.Id,
                x.UserName,
                x.DisplayName,
                x.Email,
                x.Position,
                x.Area,
                x.IsActive,
                Role = x.AppRole == null ? null : new
                {
                    x.AppRole.Id,
                    x.AppRole.Code,
                    x.AppRole.Name
                },
                Branch = x.Branch == null ? null : new
                {
                    x.Branch.Id,
                    x.Branch.Code,
                    x.Branch.Name
                }
            })
            .ToListAsync(cancellationToken);

        return Ok(users);
    }

    [HttpPost("users")]
    public async Task<IActionResult> CreateUser([FromBody] SaveUserRequest request, CancellationToken cancellationToken)
    {
        await EnsureAppUserPasswordHashColumnAsync(cancellationToken);

        var userName = NormalizeUserName(request.UserName);

        if (string.IsNullOrWhiteSpace(userName) || string.IsNullOrWhiteSpace(request.DisplayName))
        {
            return BadRequest(new { Message = "Documento/usuario y nombre son obligatorios." });
        }

        if (string.IsNullOrWhiteSpace(request.Password))
        {
            return BadRequest(new { Message = "La contraseña de acceso es obligatoria al crear usuario." });
        }

        if (request.Password.Trim().Length < 4)
        {
            return BadRequest(new { Message = "La contraseña debe tener mínimo 4 caracteres." });
        }

        var roleExists = await _context.AppRoles.AnyAsync(x => x.Id == request.AppRoleId && !x.IsDeleted, cancellationToken);

        if (!roleExists)
        {
            return BadRequest(new { Message = "El rol seleccionado no existe." });
        }

        var exists = await _context.AppUsers.AnyAsync(x => x.UserName == userName && !x.IsDeleted, cancellationToken);

        if (exists)
        {
            return Conflict(new { Message = $"Ya existe un usuario con documento/usuario {userName}." });
        }

        var user = new Navi.ToolsAssets.Domain.Entities.Security.AppUser
        {
            UserName = userName,
            DisplayName = request.DisplayName.Trim(),
            Email = request.Email?.Trim(),
            Position = request.Position?.Trim(),
            Area = request.Area?.Trim(),
            PasswordHash = HashUserPassword(request.Password),
            AppRoleId = request.AppRoleId,
            BranchId = request.BranchId,
            ResponsiblePersonId = request.ResponsiblePersonId,
            IsActive = request.IsActive ?? true,
            CreatedAt = DateTime.UtcNow,
            CreatedBy = request.ChangedBy ?? "settings"
        };

        _context.AppUsers.Add(user);
        await _context.SaveChangesAsync(cancellationToken);

        return Ok(new { user.Id, Message = "Usuario creado correctamente." });
    }







    [HttpPut("users/{id:guid}")]
    public async Task<IActionResult> UpdateUser(Guid id, [FromBody] SaveUserRequest request, CancellationToken cancellationToken)
    {
        await EnsureAppUserPasswordHashColumnAsync(cancellationToken);

        var user = await _context.AppUsers.FirstOrDefaultAsync(x => x.Id == id && !x.IsDeleted, cancellationToken);

        if (user is null)
        {
            return NotFound(new { Message = "No se encontró el usuario." });
        }

        var userName = NormalizeUserName(request.UserName);

        if (string.IsNullOrWhiteSpace(userName) || string.IsNullOrWhiteSpace(request.DisplayName))
        {
            return BadRequest(new { Message = "Documento/usuario y nombre son obligatorios." });
        }

        var roleExists = await _context.AppRoles.AnyAsync(x => x.Id == request.AppRoleId && !x.IsDeleted, cancellationToken);

        if (!roleExists)
        {
            return BadRequest(new { Message = "El rol seleccionado no existe." });
        }

        var duplicated = await _context.AppUsers
            .AnyAsync(x => x.Id != id && x.UserName == userName && !x.IsDeleted, cancellationToken);

        if (duplicated)
        {
            return Conflict(new { Message = $"Ya existe otro usuario con documento/usuario {userName}." });
        }

        user.UserName = userName;
        user.DisplayName = request.DisplayName.Trim();
        user.Email = request.Email?.Trim();
        user.Position = request.Position?.Trim();
        user.Area = request.Area?.Trim();
        user.AppRoleId = request.AppRoleId;
        user.BranchId = request.BranchId;
        user.ResponsiblePersonId = request.ResponsiblePersonId;
        user.IsActive = request.IsActive ?? user.IsActive;
        user.UpdatedAt = DateTime.UtcNow;
        user.UpdatedBy = request.ChangedBy ?? "settings";

        await _context.SaveChangesAsync(cancellationToken);

        return Ok(new { Message = "Usuario actualizado correctamente." });
    }







        [HttpPut("users/{id:guid}/password")]
    public async Task<IActionResult> ChangeUserPassword(Guid id, [FromBody] ChangeUserPasswordRequest request, CancellationToken cancellationToken)
    {
        await EnsureAppUserPasswordHashColumnAsync(cancellationToken);

        var user = await _context.AppUsers.FirstOrDefaultAsync(x => x.Id == id && !x.IsDeleted, cancellationToken);

        if (user is null)
        {
            return NotFound(new { Message = "No se encontró el usuario." });
        }

        if (string.IsNullOrWhiteSpace(request.Password))
        {
            return BadRequest(new { Message = "Debe ingresar la nueva contraseña." });
        }

        if (request.Password.Trim().Length < 4)
        {
            return BadRequest(new { Message = "La contraseña debe tener mínimo 4 caracteres." });
        }

        user.PasswordHash = HashUserPassword(request.Password);
        user.UpdatedAt = DateTime.UtcNow;
        user.UpdatedBy = request.ChangedBy ?? "settings-password";

        await _context.SaveChangesAsync(cancellationToken);

        return Ok(new { Message = "Contraseña actualizada correctamente." });
    }


    [HttpDelete("users/{id:guid}")]
    public async Task<IActionResult> DeleteUser(Guid id, [FromQuery] string? changedBy, CancellationToken cancellationToken)
    {
        var user = await _context.AppUsers.FirstOrDefaultAsync(x => x.Id == id && !x.IsDeleted, cancellationToken);

        if (user is null)
        {
            return NotFound(new { Message = "No se encontró el usuario." });
        }

        user.IsDeleted = true;
        user.IsActive = false;
        user.UpdatedAt = DateTime.UtcNow;
        user.UpdatedBy = changedBy ?? "settings";

        await _context.SaveChangesAsync(cancellationToken);

        return Ok(new { Message = "Usuario eliminado correctamente." });
    }

    // =========================================================
    // SEDES
    // =========================================================

    [HttpPost("branches")]
    public async Task<IActionResult> CreateBranch([FromBody] SaveBranchRequest request, CancellationToken cancellationToken)
    {
        var code = NormalizeCode(request.Code);

        if (string.IsNullOrWhiteSpace(code) || string.IsNullOrWhiteSpace(request.Name))
        {
            return BadRequest(new { Message = "Código y nombre son obligatorios." });
        }

        var zoneExists = await _context.Zones.AnyAsync(x => x.Id == request.ZoneId && !x.IsDeleted, cancellationToken);

        if (!zoneExists)
        {
            return BadRequest(new { Message = "La zona seleccionada no existe." });
        }

        var exists = await _context.Branches.AnyAsync(x => x.Code == code && !x.IsDeleted, cancellationToken);

        if (exists)
        {
            return Conflict(new { Message = $"Ya existe una sede con código {code}." });
        }

        var branch = new Branch
        {
            Code = code,
            Name = request.Name.Trim(),
            City = request.City?.Trim(),
            Address = request.Address?.Trim(),
            ZoneId = request.ZoneId,
            IsPilot = request.IsPilot ?? false,
            IsActive = request.IsActive ?? true,
            CreatedAt = DateTime.UtcNow,
            CreatedBy = request.ChangedBy ?? "settings"
        };

        _context.Branches.Add(branch);
        await _context.SaveChangesAsync(cancellationToken);

        return Ok(new { branch.Id, Message = "Sede creada correctamente." });
    }

    [HttpPut("branches/{id:guid}")]
    public async Task<IActionResult> UpdateBranch(Guid id, [FromBody] SaveBranchRequest request, CancellationToken cancellationToken)
    {
        var branch = await _context.Branches.FirstOrDefaultAsync(x => x.Id == id && !x.IsDeleted, cancellationToken);

        if (branch is null)
        {
            return NotFound(new { Message = "No se encontró la sede." });
        }

        var code = NormalizeCode(request.Code);

        if (string.IsNullOrWhiteSpace(code) || string.IsNullOrWhiteSpace(request.Name))
        {
            return BadRequest(new { Message = "Código y nombre son obligatorios." });
        }

        branch.Code = code;
        branch.Name = request.Name.Trim();
        branch.City = request.City?.Trim();
        branch.Address = request.Address?.Trim();
        branch.ZoneId = request.ZoneId;
        branch.IsPilot = request.IsPilot ?? branch.IsPilot;
        branch.IsActive = request.IsActive ?? branch.IsActive;
        branch.UpdatedAt = DateTime.UtcNow;
        branch.UpdatedBy = request.ChangedBy ?? "settings";

        await _context.SaveChangesAsync(cancellationToken);

        return Ok(new { Message = "Sede actualizada correctamente." });
    }

    [HttpDelete("branches/{id:guid}")]
    public async Task<IActionResult> DeleteBranch(Guid id, [FromQuery] string? changedBy, CancellationToken cancellationToken)
    {
        var branch = await _context.Branches.FirstOrDefaultAsync(x => x.Id == id && !x.IsDeleted, cancellationToken);

        if (branch is null)
        {
            return NotFound(new { Message = "No se encontró la sede." });
        }

        var hasTools = await _context.ToolAssets.AnyAsync(x => x.BranchId == id && !x.IsDeleted, cancellationToken);

        if (hasTools)
        {
            return BadRequest(new { Message = "No se puede eliminar la sede porque tiene activos asociados." });
        }

        branch.IsDeleted = true;
        branch.IsActive = false;
        branch.UpdatedAt = DateTime.UtcNow;
        branch.UpdatedBy = changedBy ?? "settings";

        await _context.SaveChangesAsync(cancellationToken);

        return Ok(new { Message = "Sede eliminada correctamente." });
    }

    // =========================================================
    // ALMACENES / TALLERES / UBICACIONES
    // =========================================================

    [HttpPost("warehouses")]
    public async Task<IActionResult> CreateWarehouse([FromBody] SaveWarehouseRequest request, CancellationToken cancellationToken)
    {
        var code = NormalizeCode(request.Code);

        if (string.IsNullOrWhiteSpace(code) || string.IsNullOrWhiteSpace(request.Name))
        {
            return BadRequest(new { Message = "Código y nombre son obligatorios." });
        }

        var branchExists = await _context.Branches.AnyAsync(x => x.Id == request.BranchId && !x.IsDeleted, cancellationToken);

        if (!branchExists)
        {
            return BadRequest(new { Message = "La sede seleccionada no existe." });
        }

        var exists = await _context.ToolLocations.AnyAsync(x => x.Code == code && !x.IsDeleted, cancellationToken);

        if (exists)
        {
            return Conflict(new { Message = $"Ya existe un almacén, taller o ubicación con código {code}." });
        }

        var location = new ToolLocation
        {
            Code = code,
            Name = request.Name.Trim(),
            Description = request.Description?.Trim(),
            BranchId = request.BranchId,
            IsActive = request.IsActive ?? true,
            CreatedAt = DateTime.UtcNow,
            CreatedBy = request.ChangedBy ?? "settings"
        };

        _context.ToolLocations.Add(location);
        await _context.SaveChangesAsync(cancellationToken);

        return Ok(new { location.Id, Message = "Almacén / taller creado correctamente." });
    }

    [HttpPut("warehouses/{id:guid}")]
    public async Task<IActionResult> UpdateWarehouse(Guid id, [FromBody] SaveWarehouseRequest request, CancellationToken cancellationToken)
    {
        var location = await _context.ToolLocations.FirstOrDefaultAsync(x => x.Id == id && !x.IsDeleted, cancellationToken);

        if (location is null)
        {
            return NotFound(new { Message = "No se encontró el almacén, taller o ubicación." });
        }

        var code = NormalizeCode(request.Code);

        if (string.IsNullOrWhiteSpace(code) || string.IsNullOrWhiteSpace(request.Name))
        {
            return BadRequest(new { Message = "Código y nombre son obligatorios." });
        }

        location.Code = code;
        location.Name = request.Name.Trim();
        location.Description = request.Description?.Trim();
        location.BranchId = request.BranchId;
        location.IsActive = request.IsActive ?? location.IsActive;
        location.UpdatedAt = DateTime.UtcNow;
        location.UpdatedBy = request.ChangedBy ?? "settings";

        await _context.SaveChangesAsync(cancellationToken);

        return Ok(new { Message = "Almacén / taller actualizado correctamente." });
    }

    [HttpDelete("warehouses/{id:guid}")]
    public async Task<IActionResult> DeleteWarehouse(Guid id, [FromQuery] string? changedBy, CancellationToken cancellationToken)
    {
        var location = await _context.ToolLocations.FirstOrDefaultAsync(x => x.Id == id && !x.IsDeleted, cancellationToken);

        if (location is null)
        {
            return NotFound(new { Message = "No se encontró el almacén, taller o ubicación." });
        }

        var hasTools = await _context.ToolAssets.AnyAsync(x => x.LocationId == id && !x.IsDeleted, cancellationToken);

        if (hasTools)
        {
            return BadRequest(new { Message = "No se puede eliminar porque tiene activos asociados." });
        }

        location.IsDeleted = true;
        location.IsActive = false;
        location.UpdatedAt = DateTime.UtcNow;
        location.UpdatedBy = changedBy ?? "settings";

        await _context.SaveChangesAsync(cancellationToken);

        return Ok(new { Message = "Almacén / taller eliminado correctamente." });
    }


    // =========================================================
    // ZONAS
    // =========================================================

    [HttpGet("zones")]
    public async Task<IActionResult> GetZones(CancellationToken cancellationToken)
    {
        var zones = await _context.Zones
            .AsNoTracking()
            .Where(x => !x.IsDeleted)
            .OrderBy(x => x.Code)
            .Select(x => new
            {
                x.Id,
                x.Code,
                x.Name,
                x.Description,
                x.IsActive
            })
            .ToListAsync(cancellationToken);

        return Ok(zones);
    }

    [HttpPost("zones")]
    public async Task<IActionResult> CreateZone([FromBody] SaveZoneRequest request, CancellationToken cancellationToken)
    {
        var code = NormalizeCode(request.Code);

        if (string.IsNullOrWhiteSpace(code) || string.IsNullOrWhiteSpace(request.Name))
        {
            return BadRequest(new { Message = "Código y nombre son obligatorios." });
        }

        var exists = await _context.Zones
            .AnyAsync(x => x.Code == code && !x.IsDeleted, cancellationToken);

        if (exists)
        {
            return Conflict(new { Message = $"Ya existe una zona con código {code}." });
        }

        var zone = new Zone
        {
            Code = code,
            Name = request.Name.Trim(),
            Description = request.Description?.Trim(),
            IsActive = request.IsActive ?? true,
            CreatedAt = DateTime.UtcNow,
            CreatedBy = request.ChangedBy ?? "settings"
        };

        _context.Zones.Add(zone);
        await _context.SaveChangesAsync(cancellationToken);

        return Ok(new { zone.Id, Message = "Zona creada correctamente." });
    }

    [HttpPut("zones/{id:guid}")]
    public async Task<IActionResult> UpdateZone(Guid id, [FromBody] SaveZoneRequest request, CancellationToken cancellationToken)
    {
        var zone = await _context.Zones
            .FirstOrDefaultAsync(x => x.Id == id && !x.IsDeleted, cancellationToken);

        if (zone is null)
        {
            return NotFound(new { Message = "No se encontró la zona." });
        }

        var code = NormalizeCode(request.Code);

        if (string.IsNullOrWhiteSpace(code) || string.IsNullOrWhiteSpace(request.Name))
        {
            return BadRequest(new { Message = "Código y nombre son obligatorios." });
        }

        var duplicated = await _context.Zones
            .AnyAsync(x => x.Id != id && x.Code == code && !x.IsDeleted, cancellationToken);

        if (duplicated)
        {
            return Conflict(new { Message = $"Ya existe otra zona con código {code}." });
        }

        zone.Code = code;
        zone.Name = request.Name.Trim();
        zone.Description = request.Description?.Trim();
        zone.IsActive = request.IsActive ?? zone.IsActive;
        zone.UpdatedAt = DateTime.UtcNow;
        zone.UpdatedBy = request.ChangedBy ?? "settings";

        await _context.SaveChangesAsync(cancellationToken);

        return Ok(new { Message = "Zona actualizada correctamente." });
    }

    [HttpDelete("zones/{id:guid}")]
    public async Task<IActionResult> DeleteZone(Guid id, [FromQuery] string? changedBy, CancellationToken cancellationToken)
    {
        var zone = await _context.Zones
            .FirstOrDefaultAsync(x => x.Id == id && !x.IsDeleted, cancellationToken);

        if (zone is null)
        {
            return NotFound(new { Message = "No se encontró la zona." });
        }

        var hasBranches = await _context.Branches
            .AnyAsync(x => x.ZoneId == id && !x.IsDeleted, cancellationToken);

        if (hasBranches)
        {
            return BadRequest(new { Message = "No se puede eliminar la zona porque tiene sedes asociadas." });
        }

        zone.IsDeleted = true;
        zone.IsActive = false;
        zone.UpdatedAt = DateTime.UtcNow;
        zone.UpdatedBy = changedBy ?? "settings";

        await _context.SaveChangesAsync(cancellationToken);

        return Ok(new { Message = "Zona eliminada correctamente." });
    }

    // =========================================================
    // CONSULTAS DE SEDES Y ALMACENES
    // =========================================================

    [HttpGet("branches")]
    public async Task<IActionResult> GetBranches(CancellationToken cancellationToken)
    {
        var branches = await _context.Branches
            .AsNoTracking()
            .Include(x => x.Zone)
            .Where(x => !x.IsDeleted)
            .OrderBy(x => x.Code)
            .Select(x => new
            {
                x.Id,
                x.Code,
                x.Name,
                x.City,
                x.Address,
                x.ZoneId,
                Zone = x.Zone == null ? null : new
                {
                    x.Zone.Id,
                    x.Zone.Code,
                    x.Zone.Name
                },
                x.IsPilot,
                x.IsActive
            })
            .ToListAsync(cancellationToken);

        return Ok(branches);
    }

    [HttpGet("warehouses")]
    public async Task<IActionResult> GetWarehouses(CancellationToken cancellationToken)
    {
        var warehouses = await _context.ToolLocations
            .AsNoTracking()
            .Include(x => x.Branch)
            .Where(x => !x.IsDeleted)
            .OrderBy(x => x.Branch == null ? "" : x.Branch.Code)
            .ThenBy(x => x.Code)
            .Select(x => new
            {
                x.Id,
                x.Code,
                x.Name,
                x.Description,
                x.BranchId,
                Branch = x.Branch == null ? null : new
                {
                    x.Branch.Id,
                    x.Branch.Code,
                    x.Branch.Name
                },
                x.IsActive
            })
            .ToListAsync(cancellationToken);

        return Ok(warehouses);
    }

    // =========================================================
    // RESPONSABLES
    // =========================================================

    [HttpGet("responsibles")]
    public async Task<IActionResult> GetResponsibles(CancellationToken cancellationToken)
    {
        var responsibles = await _context.ResponsiblePeople
            .AsNoTracking()
            .Where(x => !x.IsDeleted)
            .OrderBy(x => x.FullName)
            .Select(x => new
            {
                x.Id,
                x.EmployeeCode,
                x.DocumentNumber,
                x.FullName,
                x.Email,
                x.Position,
                x.Area,
                x.IsActive
            })
            .ToListAsync(cancellationToken);

        return Ok(responsibles);
    }

    [HttpPost("responsibles")]
    public async Task<IActionResult> CreateResponsible([FromBody] SaveResponsibleRequest request, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(request.FullName))
        {
            return BadRequest(new { Message = "El nombre completo es obligatorio." });
        }

        var employeeCode = request.EmployeeCode?.Trim();

        if (!string.IsNullOrWhiteSpace(employeeCode))
        {
            var exists = await _context.ResponsiblePeople
                .AnyAsync(x => x.EmployeeCode == employeeCode && !x.IsDeleted, cancellationToken);

            if (exists)
            {
                return Conflict(new { Message = $"Ya existe un responsable con código {employeeCode}." });
            }
        }

        var responsible = new ResponsiblePerson
        {
            EmployeeCode = employeeCode,
            DocumentNumber = request.DocumentNumber?.Trim(),
            FullName = request.FullName.Trim(),
            Email = request.Email?.Trim(),
            Position = request.Position?.Trim(),
            Area = request.Area?.Trim(),
            IsActive = request.IsActive ?? true,
            CreatedAt = DateTime.UtcNow,
            CreatedBy = request.ChangedBy ?? "settings"
        };

        _context.ResponsiblePeople.Add(responsible);
        await _context.SaveChangesAsync(cancellationToken);

        return Ok(new { responsible.Id, Message = "Responsable creado correctamente." });
    }

    [HttpPut("responsibles/{id:guid}")]
    public async Task<IActionResult> UpdateResponsible(Guid id, [FromBody] SaveResponsibleRequest request, CancellationToken cancellationToken)
    {
        var responsible = await _context.ResponsiblePeople
            .FirstOrDefaultAsync(x => x.Id == id && !x.IsDeleted, cancellationToken);

        if (responsible is null)
        {
            return NotFound(new { Message = "No se encontró el responsable." });
        }

        if (string.IsNullOrWhiteSpace(request.FullName))
        {
            return BadRequest(new { Message = "El nombre completo es obligatorio." });
        }

        var employeeCode = request.EmployeeCode?.Trim();

        if (!string.IsNullOrWhiteSpace(employeeCode))
        {
            var duplicated = await _context.ResponsiblePeople
                .AnyAsync(x => x.Id != id && x.EmployeeCode == employeeCode && !x.IsDeleted, cancellationToken);

            if (duplicated)
            {
                return Conflict(new { Message = $"Ya existe otro responsable con código {employeeCode}." });
            }
        }

        responsible.EmployeeCode = employeeCode;
        responsible.DocumentNumber = request.DocumentNumber?.Trim();
        responsible.FullName = request.FullName.Trim();
        responsible.Email = request.Email?.Trim();
        responsible.Position = request.Position?.Trim();
        responsible.Area = request.Area?.Trim();
        responsible.IsActive = request.IsActive ?? responsible.IsActive;
        responsible.UpdatedAt = DateTime.UtcNow;
        responsible.UpdatedBy = request.ChangedBy ?? "settings";

        await _context.SaveChangesAsync(cancellationToken);

        return Ok(new { Message = "Responsable actualizado correctamente." });
    }

    [HttpDelete("responsibles/{id:guid}")]
    public async Task<IActionResult> DeleteResponsible(Guid id, [FromQuery] string? changedBy, CancellationToken cancellationToken)
    {
        var responsible = await _context.ResponsiblePeople
            .FirstOrDefaultAsync(x => x.Id == id && !x.IsDeleted, cancellationToken);

        if (responsible is null)
        {
            return NotFound(new { Message = "No se encontró el responsable." });
        }

        var hasTools = await _context.ToolAssets
            .AnyAsync(x => x.ResponsiblePersonId == id && !x.IsDeleted, cancellationToken);

        if (hasTools)
        {
            return BadRequest(new { Message = "No se puede eliminar porque tiene activos asociados." });
        }

        responsible.IsDeleted = true;
        responsible.IsActive = false;
        responsible.UpdatedAt = DateTime.UtcNow;
        responsible.UpdatedBy = changedBy ?? "settings";

        await _context.SaveChangesAsync(cancellationToken);

        return Ok(new { Message = "Responsable eliminado correctamente." });
    }

    // =========================================================
    // TIPOS DE ACTIVO
    // =========================================================

    [HttpGet("asset-types")]
    public async Task<IActionResult> GetAssetTypes(CancellationToken cancellationToken)
    {
        var types = await _context.ToolTypes
            .AsNoTracking()
            .Where(x => !x.IsDeleted)
            .OrderBy(x => x.Code)
            .Select(x => new
            {
                x.Id,
                x.Code,
                x.Name,
                x.Description,
                x.IsActive
            })
            .ToListAsync(cancellationToken);

        return Ok(types);
    }

    [HttpPost("asset-types")]
    public async Task<IActionResult> CreateAssetType([FromBody] SaveCatalogRequest request, CancellationToken cancellationToken)
    {
        var code = NormalizeCode(request.Code);

        if (string.IsNullOrWhiteSpace(code) || string.IsNullOrWhiteSpace(request.Name))
        {
            return BadRequest(new { Message = "Código y nombre son obligatorios." });
        }

        var exists = await _context.ToolTypes
            .AnyAsync(x => x.Code == code && !x.IsDeleted, cancellationToken);

        if (exists)
        {
            return Conflict(new { Message = $"Ya existe un tipo de activo con código {code}." });
        }

        var type = new ToolType
        {
            Code = code,
            Name = request.Name.Trim(),
            Description = request.Description?.Trim(),
            IsActive = request.IsActive ?? true,
            CreatedAt = DateTime.UtcNow,
            CreatedBy = request.ChangedBy ?? "settings"
        };

        _context.ToolTypes.Add(type);
        await _context.SaveChangesAsync(cancellationToken);

        return Ok(new { type.Id, Message = "Tipo de activo creado correctamente." });
    }

    [HttpPut("asset-types/{id:guid}")]
    public async Task<IActionResult> UpdateAssetType(Guid id, [FromBody] SaveCatalogRequest request, CancellationToken cancellationToken)
    {
        var type = await _context.ToolTypes
            .FirstOrDefaultAsync(x => x.Id == id && !x.IsDeleted, cancellationToken);

        if (type is null)
        {
            return NotFound(new { Message = "No se encontró el tipo de activo." });
        }

        var code = NormalizeCode(request.Code);

        if (string.IsNullOrWhiteSpace(code) || string.IsNullOrWhiteSpace(request.Name))
        {
            return BadRequest(new { Message = "Código y nombre son obligatorios." });
        }

        var duplicated = await _context.ToolTypes
            .AnyAsync(x => x.Id != id && x.Code == code && !x.IsDeleted, cancellationToken);

        if (duplicated)
        {
            return Conflict(new { Message = $"Ya existe otro tipo de activo con código {code}." });
        }

        type.Code = code;
        type.Name = request.Name.Trim();
        type.Description = request.Description?.Trim();
        type.IsActive = request.IsActive ?? type.IsActive;
        type.UpdatedAt = DateTime.UtcNow;
        type.UpdatedBy = request.ChangedBy ?? "settings";

        await _context.SaveChangesAsync(cancellationToken);

        return Ok(new { Message = "Tipo de activo actualizado correctamente." });
    }

    [HttpDelete("asset-types/{id:guid}")]
    public async Task<IActionResult> DeleteAssetType(Guid id, [FromQuery] string? changedBy, CancellationToken cancellationToken)
    {
        var type = await _context.ToolTypes
            .FirstOrDefaultAsync(x => x.Id == id && !x.IsDeleted, cancellationToken);

        if (type is null)
        {
            return NotFound(new { Message = "No se encontró el tipo de activo." });
        }

        var hasTools = await _context.ToolAssets
            .AnyAsync(x => x.ToolTypeId == id && !x.IsDeleted, cancellationToken);

        if (hasTools)
        {
            return BadRequest(new { Message = "No se puede eliminar porque tiene activos asociados." });
        }

        type.IsDeleted = true;
        type.IsActive = false;
        type.UpdatedAt = DateTime.UtcNow;
        type.UpdatedBy = changedBy ?? "settings";

        await _context.SaveChangesAsync(cancellationToken);

        return Ok(new { Message = "Tipo de activo eliminado correctamente." });
    }

    // =========================================================
    // CATEGORÍAS
    // =========================================================

    [HttpGet("categories")]
    public async Task<IActionResult> GetCategories(CancellationToken cancellationToken)
    {
        var categories = await _context.ToolCategories
            .AsNoTracking()
            .Where(x => !x.IsDeleted)
            .OrderBy(x => x.Code)
            .Select(x => new
            {
                x.Id,
                x.Code,
                x.Name,
                x.Description,
                x.IsActive
            })
            .ToListAsync(cancellationToken);

        return Ok(categories);
    }

    [HttpPost("categories")]
    public async Task<IActionResult> CreateCategory([FromBody] SaveCatalogRequest request, CancellationToken cancellationToken)
    {
        var code = NormalizeCode(request.Code);

        if (string.IsNullOrWhiteSpace(code) || string.IsNullOrWhiteSpace(request.Name))
        {
            return BadRequest(new { Message = "Código y nombre son obligatorios." });
        }

        var exists = await _context.ToolCategories
            .AnyAsync(x => x.Code == code && !x.IsDeleted, cancellationToken);

        if (exists)
        {
            return Conflict(new { Message = $"Ya existe una categoría con código {code}." });
        }

        var category = new ToolCategory
        {
            Code = code,
            Name = request.Name.Trim(),
            Description = request.Description?.Trim(),
            IsActive = request.IsActive ?? true,
            CreatedAt = DateTime.UtcNow,
            CreatedBy = request.ChangedBy ?? "settings"
        };

        _context.ToolCategories.Add(category);
        await _context.SaveChangesAsync(cancellationToken);

        return Ok(new { category.Id, Message = "Categoría creada correctamente." });
    }

    [HttpPut("categories/{id:guid}")]
    public async Task<IActionResult> UpdateCategory(Guid id, [FromBody] SaveCatalogRequest request, CancellationToken cancellationToken)
    {
        var category = await _context.ToolCategories
            .FirstOrDefaultAsync(x => x.Id == id && !x.IsDeleted, cancellationToken);

        if (category is null)
        {
            return NotFound(new { Message = "No se encontró la categoría." });
        }

        var code = NormalizeCode(request.Code);

        if (string.IsNullOrWhiteSpace(code) || string.IsNullOrWhiteSpace(request.Name))
        {
            return BadRequest(new { Message = "Código y nombre son obligatorios." });
        }

        var duplicated = await _context.ToolCategories
            .AnyAsync(x => x.Id != id && x.Code == code && !x.IsDeleted, cancellationToken);

        if (duplicated)
        {
            return Conflict(new { Message = $"Ya existe otra categoría con código {code}." });
        }

        category.Code = code;
        category.Name = request.Name.Trim();
        category.Description = request.Description?.Trim();
        category.IsActive = request.IsActive ?? category.IsActive;
        category.UpdatedAt = DateTime.UtcNow;
        category.UpdatedBy = request.ChangedBy ?? "settings";

        await _context.SaveChangesAsync(cancellationToken);

        return Ok(new { Message = "Categoría actualizada correctamente." });
    }

    [HttpDelete("categories/{id:guid}")]
    public async Task<IActionResult> DeleteCategory(Guid id, [FromQuery] string? changedBy, CancellationToken cancellationToken)
    {
        var category = await _context.ToolCategories
            .FirstOrDefaultAsync(x => x.Id == id && !x.IsDeleted, cancellationToken);

        if (category is null)
        {
            return NotFound(new { Message = "No se encontró la categoría." });
        }

        var hasTools = await _context.ToolAssets
            .AnyAsync(x => x.ToolCategoryId == id && !x.IsDeleted, cancellationToken);

        if (hasTools)
        {
            return BadRequest(new { Message = "No se puede eliminar porque tiene activos asociados." });
        }

        category.IsDeleted = true;
        category.IsActive = false;
        category.UpdatedAt = DateTime.UtcNow;
        category.UpdatedBy = changedBy ?? "settings";

        await _context.SaveChangesAsync(cancellationToken);

        return Ok(new { Message = "Categoría eliminada correctamente." });
    }

    // =========================================================
    // CATÁLOGOS ADMINISTRATIVOS GENÉRICOS
    // Estados, tipos de documento y tipos de mantenimiento
    // =========================================================

    [HttpGet("statuses")]
    public async Task<IActionResult> GetStatusCatalog(CancellationToken cancellationToken)
    {
        return Ok(await GetSettingCatalogAsync("AssetStatus", cancellationToken));
    }

    [HttpPost("statuses")]
    public async Task<IActionResult> CreateStatusCatalog([FromBody] SaveCatalogRequest request, CancellationToken cancellationToken)
    {
        return await CreateSettingCatalogAsync("AssetStatus", request, cancellationToken);
    }

    [HttpPut("statuses/{id:guid}")]
    public async Task<IActionResult> UpdateStatusCatalog(Guid id, [FromBody] SaveCatalogRequest request, CancellationToken cancellationToken)
    {
        return await UpdateSettingCatalogAsync("AssetStatus", id, request, cancellationToken);
    }

    [HttpDelete("statuses/{id:guid}")]
    public async Task<IActionResult> DeleteStatusCatalog(Guid id, [FromQuery] string? changedBy, CancellationToken cancellationToken)
    {
        return await DeleteSettingCatalogAsync("AssetStatus", id, changedBy, cancellationToken);
    }

    [HttpGet("document-types")]
    public async Task<IActionResult> GetDocumentTypeCatalog(CancellationToken cancellationToken)
    {
        return Ok(await GetSettingCatalogAsync("DocumentType", cancellationToken));
    }

    [HttpPost("document-types")]
    public async Task<IActionResult> CreateDocumentTypeCatalog([FromBody] SaveCatalogRequest request, CancellationToken cancellationToken)
    {
        return await CreateSettingCatalogAsync("DocumentType", request, cancellationToken);
    }

    [HttpPut("document-types/{id:guid}")]
    public async Task<IActionResult> UpdateDocumentTypeCatalog(Guid id, [FromBody] SaveCatalogRequest request, CancellationToken cancellationToken)
    {
        return await UpdateSettingCatalogAsync("DocumentType", id, request, cancellationToken);
    }

    [HttpDelete("document-types/{id:guid}")]
    public async Task<IActionResult> DeleteDocumentTypeCatalog(Guid id, [FromQuery] string? changedBy, CancellationToken cancellationToken)
    {
        return await DeleteSettingCatalogAsync("DocumentType", id, changedBy, cancellationToken);
    }

    [HttpGet("maintenance-types")]
    public async Task<IActionResult> GetMaintenanceTypeCatalog(CancellationToken cancellationToken)
    {
        return Ok(await GetSettingCatalogAsync("MaintenanceType", cancellationToken));
    }

    [HttpPost("maintenance-types")]
    public async Task<IActionResult> CreateMaintenanceTypeCatalog([FromBody] SaveCatalogRequest request, CancellationToken cancellationToken)
    {
        return await CreateSettingCatalogAsync("MaintenanceType", request, cancellationToken);
    }

    [HttpPut("maintenance-types/{id:guid}")]
    public async Task<IActionResult> UpdateMaintenanceTypeCatalog(Guid id, [FromBody] SaveCatalogRequest request, CancellationToken cancellationToken)
    {
        return await UpdateSettingCatalogAsync("MaintenanceType", id, request, cancellationToken);
    }

    [HttpDelete("maintenance-types/{id:guid}")]
    public async Task<IActionResult> DeleteMaintenanceTypeCatalog(Guid id, [FromQuery] string? changedBy, CancellationToken cancellationToken)
    {
        return await DeleteSettingCatalogAsync("MaintenanceType", id, changedBy, cancellationToken);
    }

    private async Task<List<object>> GetSettingCatalogAsync(string catalogType, CancellationToken cancellationToken)
    {
        var items = await _context.SettingCatalogItems
            .AsNoTracking()
            .Where(x => x.CatalogType == catalogType && !x.IsDeleted)
            .OrderBy(x => x.Code)
            .Select(x => new
            {
                x.Id,
                x.Code,
                x.Name,
                x.Description,
                x.IsActive
            })
            .ToListAsync(cancellationToken);

        return items.Cast<object>().ToList();
    }

    private async Task<IActionResult> CreateSettingCatalogAsync(string catalogType, SaveCatalogRequest request, CancellationToken cancellationToken)
    {
        var code = NormalizeCode(request.Code);

        if (string.IsNullOrWhiteSpace(code) || string.IsNullOrWhiteSpace(request.Name))
        {
            return BadRequest(new { Message = "Código y nombre son obligatorios." });
        }

        var exists = await _context.SettingCatalogItems
            .AnyAsync(x => x.CatalogType == catalogType && x.Code == code && !x.IsDeleted, cancellationToken);

        if (exists)
        {
            return Conflict(new { Message = $"Ya existe un registro con código {code}." });
        }

        var item = new SettingCatalogItem
        {
            CatalogType = catalogType,
            Code = code,
            Name = request.Name.Trim(),
            Description = request.Description?.Trim(),
            IsActive = request.IsActive ?? true,
            CreatedAt = DateTime.UtcNow,
            CreatedBy = request.ChangedBy ?? "settings"
        };

        _context.SettingCatalogItems.Add(item);
        await _context.SaveChangesAsync(cancellationToken);

        return Ok(new { item.Id, Message = "Registro creado correctamente." });
    }

    private async Task<IActionResult> UpdateSettingCatalogAsync(string catalogType, Guid id, SaveCatalogRequest request, CancellationToken cancellationToken)
    {
        var item = await _context.SettingCatalogItems
            .FirstOrDefaultAsync(x => x.Id == id && x.CatalogType == catalogType && !x.IsDeleted, cancellationToken);

        if (item is null)
        {
            return NotFound(new { Message = "No se encontró el registro." });
        }

        var code = NormalizeCode(request.Code);

        if (string.IsNullOrWhiteSpace(code) || string.IsNullOrWhiteSpace(request.Name))
        {
            return BadRequest(new { Message = "Código y nombre son obligatorios." });
        }

        var duplicated = await _context.SettingCatalogItems
            .AnyAsync(x => x.Id != id && x.CatalogType == catalogType && x.Code == code && !x.IsDeleted, cancellationToken);

        if (duplicated)
        {
            return Conflict(new { Message = $"Ya existe otro registro con código {code}." });
        }

        item.Code = code;
        item.Name = request.Name.Trim();
        item.Description = request.Description?.Trim();
        item.IsActive = request.IsActive ?? item.IsActive;
        item.UpdatedAt = DateTime.UtcNow;
        item.UpdatedBy = request.ChangedBy ?? "settings";

        await _context.SaveChangesAsync(cancellationToken);

        return Ok(new { Message = "Registro actualizado correctamente." });
    }

    private async Task<IActionResult> DeleteSettingCatalogAsync(string catalogType, Guid id, string? changedBy, CancellationToken cancellationToken)
    {
        var item = await _context.SettingCatalogItems
            .FirstOrDefaultAsync(x => x.Id == id && x.CatalogType == catalogType && !x.IsDeleted, cancellationToken);

        if (item is null)
        {
            return NotFound(new { Message = "No se encontró el registro." });
        }

        item.IsDeleted = true;
        item.IsActive = false;
        item.UpdatedAt = DateTime.UtcNow;
        item.UpdatedBy = changedBy ?? "settings";

        await _context.SaveChangesAsync(cancellationToken);

        return Ok(new { Message = "Registro eliminado correctamente." });
    }

    // =========================================================
    // CAUSALES, PARÁMETROS Y PLANES DE MANTENIMIENTO
    // Catálogos administrativos genéricos
    // =========================================================

    [HttpGet("causes")]
    public async Task<IActionResult> GetCausesCatalog(CancellationToken cancellationToken)
    {
        return Ok(await GetSettingCatalogAsync("Cause", cancellationToken));
    }

    [HttpPost("causes")]
    public async Task<IActionResult> CreateCauseCatalog([FromBody] SaveCatalogRequest request, CancellationToken cancellationToken)
    {
        return await CreateSettingCatalogAsync("Cause", request, cancellationToken);
    }

    [HttpPut("causes/{id:guid}")]
    public async Task<IActionResult> UpdateCauseCatalog(Guid id, [FromBody] SaveCatalogRequest request, CancellationToken cancellationToken)
    {
        return await UpdateSettingCatalogAsync("Cause", id, request, cancellationToken);
    }

    [HttpDelete("causes/{id:guid}")]
    public async Task<IActionResult> DeleteCauseCatalog(Guid id, [FromQuery] string? changedBy, CancellationToken cancellationToken)
    {
        return await DeleteSettingCatalogAsync("Cause", id, changedBy, cancellationToken);
    }

    [HttpGet("admin-parameters")]
    public async Task<IActionResult> GetAdminParametersCatalog(CancellationToken cancellationToken)
    {
        return Ok(await GetSettingCatalogAsync("AdminParameter", cancellationToken));
    }

    [HttpPost("admin-parameters")]
    public async Task<IActionResult> CreateAdminParameterCatalog([FromBody] SaveCatalogRequest request, CancellationToken cancellationToken)
    {
        return await CreateSettingCatalogAsync("AdminParameter", request, cancellationToken);
    }

    [HttpPut("admin-parameters/{id:guid}")]
    public async Task<IActionResult> UpdateAdminParameterCatalog(Guid id, [FromBody] SaveCatalogRequest request, CancellationToken cancellationToken)
    {
        return await UpdateSettingCatalogAsync("AdminParameter", id, request, cancellationToken);
    }

    [HttpDelete("admin-parameters/{id:guid}")]
    public async Task<IActionResult> DeleteAdminParameterCatalog(Guid id, [FromQuery] string? changedBy, CancellationToken cancellationToken)
    {
        return await DeleteSettingCatalogAsync("AdminParameter", id, changedBy, cancellationToken);
    }

    [HttpGet("maintenance-plans")]
    public async Task<IActionResult> GetMaintenancePlansCatalog(CancellationToken cancellationToken)
    {
        return Ok(await GetSettingCatalogAsync("MaintenancePlan", cancellationToken));
    }

    [HttpPost("maintenance-plans")]
    public async Task<IActionResult> CreateMaintenancePlanCatalog([FromBody] SaveCatalogRequest request, CancellationToken cancellationToken)
    {
        return await CreateSettingCatalogAsync("MaintenancePlan", request, cancellationToken);
    }

    [HttpPut("maintenance-plans/{id:guid}")]
    public async Task<IActionResult> UpdateMaintenancePlanCatalog(Guid id, [FromBody] SaveCatalogRequest request, CancellationToken cancellationToken)
    {
        return await UpdateSettingCatalogAsync("MaintenancePlan", id, request, cancellationToken);
    }

    [HttpDelete("maintenance-plans/{id:guid}")]
    public async Task<IActionResult> DeleteMaintenancePlanCatalog(Guid id, [FromQuery] string? changedBy, CancellationToken cancellationToken)
    {
        return await DeleteSettingCatalogAsync("MaintenancePlan", id, changedBy, cancellationToken);
    }
    private async Task EnsureAppUserPasswordHashColumnAsync(CancellationToken cancellationToken)
    {
        var entityType = _context.Model.FindEntityType(typeof(Navi.ToolsAssets.Domain.Entities.Security.AppUser));

        var tableName = entityType?.GetTableName();

        if (string.IsNullOrWhiteSpace(tableName))
        {
            tableName = "AppUsers";
        }

        var schema = entityType?.GetSchema();

        static string SqlValue(string? value)
        {
            return (value ?? string.Empty).Replace("'", "''");
        }

        var schemaValue = SqlValue(schema);
        var tableValue = SqlValue(tableName);

        var sql = $@"
DECLARE @SchemaName sysname = NULLIF(N'{schemaValue}', N'');
DECLARE @TableName sysname = N'{tableValue}';

IF @SchemaName IS NULL
BEGIN
    SELECT TOP(1) @SchemaName = s.name
    FROM sys.tables t
    INNER JOIN sys.schemas s ON s.schema_id = t.schema_id
    WHERE t.name = @TableName;
END

IF @SchemaName IS NULL
BEGIN
    THROW 50000, 'No se encontro la tabla AppUsers en la base de datos.', 1;
END

DECLARE @QualifiedTable nvarchar(300) = QUOTENAME(@SchemaName) + N'.' + QUOTENAME(@TableName);

IF COL_LENGTH(@QualifiedTable, N'PasswordHash') IS NULL
BEGIN
    DECLARE @AlterSql nvarchar(max) = N'ALTER TABLE ' + @QualifiedTable + N' ADD [PasswordHash] nvarchar(500) NULL;';
    EXEC sp_executesql @AlterSql;
END
";

        await _context.Database.ExecuteSqlRawAsync(sql, cancellationToken);
    }

    private static string HashUserPassword(string password)
    {
        var value = password.Trim();
        var bytes = SHA256.HashData(Encoding.UTF8.GetBytes(value));
        return Convert.ToHexString(bytes);
    }
    private static string NormalizeCode(string? code)
    {
        return (code ?? string.Empty).Trim().ToUpperInvariant();
    }

        private async Task EnsureSecurityUsersPasswordSchemaAsync(CancellationToken cancellationToken)
    {
        var sql = @"
IF COL_LENGTH('Security.AppUsers', 'PasswordHash') IS NULL
BEGIN
    ALTER TABLE [Security].[AppUsers] ADD [PasswordHash] nvarchar(500) NULL;
END
";

        await _context.Database.ExecuteSqlRawAsync(sql, cancellationToken);
    }

    private static string HashPassword(string password)
    {
        var value = password.Trim();
        var bytes = SHA256.HashData(Encoding.UTF8.GetBytes(value));
        return Convert.ToHexString(bytes);
    }

    private static string NormalizeUserName(string? userName)
    {
        return (userName ?? string.Empty).Trim().ToLowerInvariant();
    }
}



public sealed class SaveResponsibleRequest
{
    public string? EmployeeCode { get; set; }
    public string? DocumentNumber { get; set; }
    public string FullName { get; set; } = string.Empty;
    public string? Email { get; set; }
    public string? Position { get; set; }
    public string? Area { get; set; }
    public string? Password { get; set; }
    public bool? IsActive { get; set; }
    public string? ChangedBy { get; set; }
}

public sealed class SaveCatalogRequest
{
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public bool? IsActive { get; set; }
    public string? ChangedBy { get; set; }
}
public sealed class SaveZoneRequest
{
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public bool? IsActive { get; set; }
    public string? ChangedBy { get; set; }
}
public sealed class SaveRoleRequest
{
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public string? Permissions { get; set; }
    public bool? IsActive { get; set; }
    public string? ChangedBy { get; set; }
}

public sealed class SaveUserRequest
{
    public string UserName { get; set; } = string.Empty;
    public string DisplayName { get; set; } = string.Empty;
    public string? Email { get; set; }
    public string? Position { get; set; }
    public string? Area { get; set; }
    public string? Password { get; set; }
    public Guid AppRoleId { get; set; }
    public Guid? BranchId { get; set; }
    public Guid? ResponsiblePersonId { get; set; }
    public bool? IsActive { get; set; }
    public string? ChangedBy { get; set; }
}

public sealed class ChangeUserPasswordRequest
{
    public string? Password { get; set; }
    public string? ChangedBy { get; set; }
}

public sealed class SaveBranchRequest
{
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? City { get; set; }
    public string? Address { get; set; }
    public Guid ZoneId { get; set; }
    public bool? IsPilot { get; set; }
    public bool? IsActive { get; set; }
    public string? ChangedBy { get; set; }
}

public sealed class SaveWarehouseRequest
{
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public Guid BranchId { get; set; }
    public bool? IsActive { get; set; }
    public string? ChangedBy { get; set; }
}
























