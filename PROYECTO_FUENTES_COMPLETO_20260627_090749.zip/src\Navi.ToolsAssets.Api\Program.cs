﻿using Hangfire;
using Hangfire.SqlServer;
using Navi.ToolsAssets.Infrastructure.Extensions;
using Navi.ToolsAssets.Infrastructure.Seed;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddAuthorization();

builder.Services.AddCors(options =>
{
    options.AddPolicy("NaviMobileCors", policy =>
    {
        policy
            .WithOrigins(
                "http://localhost:5285",
                "https://localhost:7285",
                "http://localhost:5264",
                "https://localhost:7264")
            .AllowAnyHeader()
            .AllowAnyMethod();
    });
});

builder.Services.AddInfrastructure(builder.Configuration);

var connectionString = builder.Configuration.GetConnectionString("NaviToolsAssetsDb")
    ?? throw new InvalidOperationException("No se encontró la cadena de conexión 'NaviToolsAssetsDb'.");

builder.Services.AddHangfire(configuration =>
{
    configuration
        .SetDataCompatibilityLevel(CompatibilityLevel.Version_180)
        .UseSimpleAssemblyNameTypeSerializer()
        .UseRecommendedSerializerSettings()
        .UseSqlServerStorage(connectionString, new SqlServerStorageOptions
        {
            CommandBatchMaxTimeout = TimeSpan.FromMinutes(5),
            SlidingInvisibilityTimeout = TimeSpan.FromMinutes(5),
            QueuePollInterval = TimeSpan.FromSeconds(15),
            UseRecommendedIsolationLevel = true,
            DisableGlobalLocks = true,
            SchemaName = "HangFire",
            PrepareSchemaIfNecessary = true
        });
});

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    await app.Services.SeedDatabaseAsync();

    app.UseSwagger();
    app.UseSwaggerUI();

    app.UseHangfireDashboard("/hangfire");
}

app.UseHttpsRedirection();

app.UseCors("NaviMobileCors");

app.UseAuthorization();

app.MapControllers();

app.MapGet("/", () => Results.Ok(new
{
    App = "NAVI Herramientas API",
    Status = "Running",
    Database = "NaviToolsAssetsDb",
    Seed = "AGU / Zona Antioquia / Catálogos base",
    Hangfire = "/hangfire"
}));

app.Run();

